### libraries
	library(foreach)
	library(data.table)
	library(doMC)
	
### set number of threads
	registerDoMC(4)

#### data
	#load("6d.Rdata")
	head_txn <- fread("Head_Match.txt")
	ovary_txn <- fread("Ovary_Match.txt")
	
	head_txn <- na.omit(head_txn)
	ovary_txn <- na.omit(ovary_txn)
	
	head_txn$id <- c(1:dim(head_txn)[1])
	ovary_txn$id <- c(1:dim(ovary_txn)[1])
	
### functions

	matchControl <- function(targetId, param, paramId=NULL, exclude=NULL, nBoot=5, method=2) {
			if(method==1) {
				len <- length(targetId)
				if(nBoot>0) {
					out <- cbind(targetId, do.call("rbind", foreach(i=1:len, .export=c("param", "targetId", "nBoot", "len", "exclude"))%dopar% {
						#print(paste(i, " / ", len, sep=""))
				#			potentialIds <- param[J(param[param$id==targetId[i], -dim(param)[2], with=FALSE])]$id  ## try to make this line vectorized
						potentialIds <- param[J(param[id==targetId[i], -dim(param)[2], with=FALSE]), nomatch=0]$id  ## try to make this line vectorized

						potentialIds <- potentialIds[!potentialIds%in%targetId]
	
						if(!is.null(exclude)) {
							potentialIds <- potentialIds[!exclude[potentialIds]]
						}
	
						ret <- NULL
						if(length(potentialIds)>0) {
							ret <- as.numeric(sample(as.character(potentialIds), nBoot, replace=TRUE))
						} else {
							ret <- rep(NA, nBoot)
						}
						ret
					}))
				} else {
					out <- matrix(targetId, ncol=1)
				}
				if(!is.null(ret)) ret <- ret[!ret$id.control%in%exclude]

			} else if(method==2) {
				origParamKey <- key(param)
				setkey(param, id)
				targetDt <- copy(param[J(targetId)])
		
				setkeyv(param, origParamKey)
				setkeyv(targetDt, origParamKey)
		
				setnames(param, "id", "id.control")
				setnames(targetDt, "id", "id.target")
			
				ret <- param[targetDt, allow.cartesian=T]
			
			
				ret <- ret[!ret$id.control%in%targetId]
				
				if(!is.null(ret)) ret <- ret[!ret$id.control%in%exclude]
				
				ret$id[is.na(ret$id.control)]<-0
		
				sampRet <- ret[,as.numeric(sample(as.character(id.control), nBoot, replace=T)),id.target]
			
				ret <- matrix(sampRet$V1, nrow=dim(sampRet)[1]/nBoot, ncol=nBoot, byrow=T)
		
		
				out <- cbind(matrix(sampRet$id.target, nrow=dim(sampRet)[1]/nBoot, ncol=nBoot, byrow=T)[,1], ret)			
				ret[ret==0] <- NA
		
			} else if(method==3) {
				targetDt <- paramId[targetId]
		
				setkeyv(targetDt, key(param))
		
				ret <- param[J(targetDt), nomatch=NA, allow.cartesian=TRUE]
				#ret <- param[J(targetDt), nomatch=NA]
		
		
				ret <- ret[!ret$id%in%targetId]
		
				if(!is.null(exclude)) {
					ret <- ret[!ret$id%in%exclude]		
				}
		
		
				if(dim(ret)[1]>0) {
					ret$id[is.na(ret$id)]<-0
					sampRet <- ret[,as.numeric(sample(id,nBoot, replace=T)),id.1]
		
					ret <- matrix(sampRet$V1, nrow=dim(sampRet)[1]/nBoot, ncol=nBoot, byrow=T)
		
		
					out <- cbind(matrix(sampRet$id.1, nrow=dim(sampRet)[1]/nBoot, ncol=nBoot, byrow=T)[,1], ret)
					out[out==0] <- NA
				} else {
					out <- matrix(c(targetId, rep(NA, nBoot)), nrow=1)
				}
			}
			
			out
		}
		
	
	cleanMean <- function(x) mean(x[x!=Inf & x!=-Inf & !is.nan(x) & !is.na(x)])
	cleanMedian <- function(x) median(x[x!=Inf & x!=-Inf & !is.nan(x) & !is.na(x)])
	
	cleanSd <- function(x) sd(x[x!=Inf & x!=-Inf & !is.nan(x) & !is.na(x)])
	cleanQuan <- function(x, q) quantile(x[x!=Inf & x!=-Inf & !is.nan(x) & !is.na(x)], q)
	
	
	blockBoot <- function(dt, window=50000, nBoot=50) {
		### dt must take form: chr, pos
		dt <- as.data.table(dt)
		dt$id <- c(1:dim(dt)[1])
		dt$chr <- as.character(dt$chr)

		setkey(dt, chr)		

		tempOut <- foreach(k=unique(dt$chr))%dopar%{
			tempDt <- dt[k]
			tempDt$posBin <- floor(tempDt$pos/window)*window
			setkey(tempDt, posBin)
			
			out <- tempDt[,list(id=as.numeric(sample(as.character(id), nBoot, replace=T)), rep=c(1:nBoot)),
					list(posBin=posBin)]
			
			setkey(tempDt, id)
			
			out$chr <- tempDt[J(out$id)]$chr
			out$pos <- tempDt[J(out$id)]$pos
			out
		}
		#tempOut <- rbindlist(tempOut)
		tempOut <- do.call("rbind", tempOut)
		
		setkey(tempOut, rep)
		tempOut
	}	
	
	analysisWrapper <- function(targetVec, controlDt, test.dt, nBoot=500, nBlockBoot=500, window=100000, class, minUniqFrac=.1) {
		
		### first, generate control set of genes
			
			controlMat <- matchControl(targetId=targetVec,
										param=copy(controlDt),
										nBoot=nBoot,
										method=2)
		
		### strip out DE genes that dont' have enough matched controls
			nUniq <- apply(controlMat[,-1], 1, function(x) length(unique(x)))
			controlMat <- controlMat[nUniq>round(minUniqFrac*nBoot),]
			
		### generate blocks
			setkey(test.dt, id)
			de.bb <- blockBoot(dt=data.table(chr=test.dt$chr[controlMat[,1]], pos=test.dt$pos[controlMat[,1]]), window=window, nBoot=nBlockBoot)
		
		### calculate enrichment
			setkey(test.dt, id)
		
			target <- test.dt[J(controlMat[,1])][de.bb$id]
			target$block <- de.bb$rep
			target.ag <- target[,list(season.T=sum(seasonal), season.F=sum(!seasonal), 
										clinal.T=sum(clinal), clinal.F=sum(!clinal)),
								block]
			setkey(target.ag, block)
			
			o <- do.call("rbind", foreach(i=2:dim(controlMat)[2])%dopar%{		
				print(i)
				control<-test.dt[J(controlMat[,i])][de.bb$id]
				control$block <- de.bb$rep
				control.ag <- control[,list(season.T=sum(seasonal), season.F=sum(!seasonal), 
										clinal.T=sum(clinal), clinal.F=sum(!clinal)),
								block]
				setkey(control.ag, block)
			
				tc <- merge(target.ag, control.ag)
				
				data.table(boot=i, blockBoot=tc$block, class=class,
							season.or=(tc$season.T.x/tc$season.F.x)/(tc$season.T.y/tc$season.F.y),
							cline.or=(tc$clinal.T.x/tc$clinal.F.x)/(tc$clinal.T.y/tc$clinal.F.y))
			
			})
			
			
		### summarize
			o.ag <- o[,list(season.or=cleanMedian(log2(season.or)), cline.or=cleanMedian(log2(cline.or))), list(boot, class)]	
			
			o.ag.ag <- o.ag[,list(season.mu=cleanMean(season.or), season.sd=cleanSd(season.or), season.pr=mean(season.or>0), season.lci=cleanQuan(season.or, .025), season.uci=cleanQuan(season.or, .975),
								cline.mu=cleanMean(cline.or), cline.sd=cleanSd(cline.or), cline.pr=mean(cline.or>0), cline.lci=cleanQuan(cline.or, 0.025), cline.uci=cleanQuan(cline.or, 0.975)), class]
		
    
		
    
			
		### return
			return(o.ag.ag)
	}
			
			
		
### analysis

	### set up output object
		en_out <- list()

	### for each class 
		## head_down
			en_out[[1]] <- analysisWrapper(targetVec=head_txn[D_head_norm < ND_head_norm & DE]$id,	
											controlDt=data.table(chrom=head_txn$Chrom,
																length=round(head_txn$length/500)*500,
																mean_RPKM=round(log10(head_txn$mean_RPKM*2))*2,
																id=head_txn$id,
																key="chrom,length,mean_RPKM"),
											test.dt=data.table(id=head_txn$id,
																seasonal=head_txn$Seasonal,
																clinal=head_txn$Clinal,
																chr=head_txn$Chrom,
																pos=head_txn$Start/2 + head_txn$End/2),
											class="head_down")
		
		
		## head_up
			en_out[[2]] <- analysisWrapper(targetVec=head_txn[D_head_norm > ND_head_norm & DE]$id,	
											controlDt=data.table(chrom=head_txn$Chrom,
																length=round(head_txn$length/500)*500,
																mean_RPKM=round(log10(head_txn$mean_RPKM*2))*2,
																id=head_txn$id,
																key="chrom,length,mean_RPKM"),
											test.dt=data.table(id=head_txn$id,
																seasonal=head_txn$Seasonal,
																clinal=head_txn$Clinal,
																chr=head_txn$Chrom,
																pos=head_txn$Start/2 + head_txn$End/2),
											class="head_up")
		
		## ovary_down
			en_out[[3]] <- analysisWrapper(targetVec=ovary_txn[D_ovary_norm < ND_ovary_norm & DE]$id,	
											controlDt=data.table(chrom= ovary_txn $Chrom,
																length=round(ovary_txn $length/500)*500,
																mean_RPKM=round(log10(ovary_txn $mean_RPKM*2))*2,
																id= ovary_txn $id,
																key="chrom,length,mean_RPKM"),
											test.dt=data.table(id= ovary_txn $id,
																seasonal= ovary_txn $Seasonal,
																clinal= ovary_txn $Clinal,
																chr= ovary_txn $Chrom,
																pos= ovary_txn $Start/2 + ovary_txn $End/2),
											class="ovary_down")
		
	
	
		## ovary_up
			en_out[[4]] <- analysisWrapper(targetVec=ovary_txn[D_ovary_norm > ND_ovary_norm & DE]$id,	
											controlDt=data.table(chrom= ovary_txn $Chrom,
																length=round(ovary_txn $length/500)*500,
																mean_RPKM=round(log10(ovary_txn $mean_RPKM*2))*2,
																id= ovary_txn $id,
																key="chrom,length,mean_RPKM"),
											test.dt=data.table(id= ovary_txn $id,
																seasonal= ovary_txn $Seasonal,
																clinal= ovary_txn $Clinal,
																chr= ovary_txn $Chrom,
																pos= ovary_txn $Start/2 + ovary_txn $End/2),
											class="ovary_up")
		
	
	### merge together
		en_out <- rbindlist(en_out)































	geneControl <- matchControl(targetId=gmt[class=="pigmentation"]$id,
								param=data.table(chr=gmt$chr,
												dist=round(gmt$dist, -3),
												id=gmt$id,
												key=c("chr,dist")),
								nBoot=100)
	
	
	setkey(gmt, id)
	setkey(ps, chr, pos)
	
	window <- 10000
	
	
	
	o <- do.call("rbind", foreach(i=1:2)%do%{
		genes <- gmt[geneControl[,i]]
		genes$targetGeneV <- geneControl[,1]
	
		loc.dt <- genes[,list(chr=chr, pos=c((start-window):(stop+window)), targetGeneV=unique(targetGeneV), gene=unique(gene)), list(ord=c(1:dim(genes)[1]))]
		
		setkey(loc.dt, chr, pos)
		setkey(ps, chr, pos)
		ps.loc <- ps[J(loc.dt), nomatch=0]
		setkey(ps.loc, id)
		ps.loc <- ps.loc[!duplicated(ps.loc)]
		
		
		snp.control <- matchControl(targetId=ps.loc$id,
									param=data.table(chr=ps$chr,
													rec=round(ps$rec, -1),
													het=round(ps$het, 2),
													rd=round(ps$medRd, 1),
													id=ps$id,
													key=c("chr,rec,het,rd")),
									nBoot=100, method=2)
		
		
		#ps.blockBoot <- blockBoot(dt=data.table(chr=ps.loc$chr, pos=ps.loc$pos), window=5)
		#setkey(ps.blockBoot, chr, pos)

		setkey(ps, id)
		setkey(ps.loc, id)
		
		pcut <- 1e-3
		

	
		do.call("rbind", foreach(pcut=expand.grid(sapply(c(1:9), FUN=function(x) x*10^c(-5:-1)))[,1])%do%{

			do.call("rbind", foreach(j=1:dim(snp.control)[2])%dopar%{
				print(paste(i, j, sep=" / "))
	
				loc.temp <- ps[J(snp.control[,j])]
				loc.temp$targetGeneV <- ps.loc[J(snp.control[,1])]$targetGeneV
				
				loc.temp[,list(nT.c=sum(cq<=pcut), nF.c=sum(cq>pcut), boot=j, geneBoot=i, pcut=pcut), targetGeneV]
				
			
			})	
		})
	
	
	})
	
	offset <- 0.5
	
	o.or <- o[,list(or=(log2(((nT.c[boot==1]+offset)/(nF.c[boot==1]+offset))/((nT.c[boot!=1]+offset)/(nF.c[boot!=1]+offset))))), 
				list(pcut, geneBoot, targetGeneV)]

	o.or.ag <- o.or[,list(or=cleanMedian(or), lci=cleanQuan(or, .025), uci=cleanQuan(or, .975)), list(pcut, targetGeneV, geneBoot)]

	o.or.ag$gene <- gmt[J(o.or.ag$targetGeneV)]$gene
	
	o.or.ag <- o.or.ag[order(o.or.ag$pcut)]
	plot(or~log10(pcut), o.or.ag, type="n")
	for(i in unique(o.or.ag$gene)) {
		points(or~log10(pcut), o.or.ag[gene==i & geneBoot==1], type="l", col=rgb(0,0,0,.5))
	}
	
	
	
	
	
	
	
	
	o <- do.call("rbind", foreach(i=1:10)%do%{
		print(i)
		
		
		loc.dt <- gmt[J(geneControl[,i]),
						list(chr=chr, pos=c((start-window):(stop+window)), gene=gene),]
		
		loc.dt$target.id <- geneControl[,
		
		
		setkey(loc.dt, chr, pos)
		
		ps.loc <- ps[J(loc.dt), nomatch=0]
		ps.blockBoot <- blockBoot(dt=data.table(chr=ps.loc$chr, pos=ps.loc$pos), window=5)
		setkey(ps.blockBoot, chr, pos)
		
		
		ps.booted <- ps.loc[J(ps.blockBoot), allow.cartesian=T]

		
		#ps.loc.ag <- ps.loc[,list(nT.c=sum(cq<=.05), nF.c=sum(cq>.05)), list(gene)]
	
	
		do.call("rbind", foreach(k=expand.grid(sapply(c(1:9), FUN=function(x) x*10^c(-5:-1)))[,1])%do%{

			ps.booted[,list(nT.c=sum(cq<=k), nF.c=sum(cq>k), pcut=k, boot=i), list(blockBoot=rep, gene=gene)]
	
		})
	})
	setkey(o, boot, blockBoot)
	
	o.or <- o[,list(or=cleanMedian(log2((nT.c[boot==1]/nF.c[boot==1])/(nT.c[boot!=1]/nF.c[boot!=1])))), list(pcut, blockBoot, gene)]
	o.or.ag <- o.or[,list(or=cleanMedian(or), lci=cleanQuan(or, .025), uci=cleanQuan(or, .975)), list(pcut, gene)]
	
	
	o.or.ag <- o.or.ag[order(o.or.ag$pcut)]  
	plot(or~log10(pcut), o.or.ag, type="l")
	
	
	
	
