library(ggplot2)
library(gridExtra) 

out<-read.table("output.txt", header=T) 

SeaPlot<-ggplot(out, aes(x=class, y=season.mu))+geom_errorbar(aes(ymin=season.lci, ymax=season.uci), width=0.1)+geom_line()+geom_point(size=3)+geom_hline(aes(yintercept=0), colour="red", linetype="dashed")+theme_bw()+ggtitle("Seasonal Enrichment")+scale_y_continuous("log2 odds ratio",limits=c(-1,3))+scale_x_discrete(limits=c("head_up","head_down","ovary_up","ovary_down"), labels=c("Up-regulated in D head","Down-regulated in D head","Up-regulated in D ovary","Down-regulated in D ovary"))+theme(axis.title.x=element_blank(), axis.text.x=element_text(angle=40, hjust=1, vjust=1))+geom_text(x=2, y=1.6, label="*", size=8, colour="red")  

CliPlot<-ggplot(out, aes(x=class, y=cline.mu))+geom_errorbar(aes(ymin=cline.lci, ymax=cline.uci), width=0.1)+geom_line()+geom_point(size=3)+geom_hline(aes(yintercept=0), colour="red", linetype="dashed")+theme_bw()+ggtitle("Clinal Enrichment")+scale_y_continuous("log2 odds ratio",limits=c(-1,3))+scale_x_discrete(limits=c("head_up","head_down","ovary_up","ovary_down"), labels=c("Up-regulated in D head","Down-regulated in D head","Up-regulated in D ovary","Down-regulated in D ovary"))+theme(axis.title.x=element_blank(), axis.text.x=element_text(angle=40, hjust=1, vjust=1))+geom_text(x=2, y=1, label="*", size=8, colour="red") 

grid.arrange(CliPlot,SeaPlot,ncol=2) 
