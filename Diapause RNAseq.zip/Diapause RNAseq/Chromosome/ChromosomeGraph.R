###In Terminal, make files that contains the location of genes for each chromosome 

#hntvlan554:Chromosome xiaqingzhao$ grep '2L:' Gene_Loc_All > Gene_Loc_2L 
#hntvlan554:Chromosome xiaqingzhao$ grep '2R:' Gene_Loc_All > Gene_Loc_2R 
#hntvlan554:Chromosome xiaqingzhao$ grep '3L:' Gene_Loc_All > Gene_Loc_3L 
#hntvlan554:Chromosome xiaqingzhao$ grep '3R:' Gene_Loc_All > Gene_Loc_3R 
#hntvlan554:Chromosome xiaqingzhao$ grep 'X:' Gene_Loc_All > Gene_Loc_X 
#hntvlan554:Chromosome xiaqingzhao$ grep '\t4:' Gene_Loc_All > Gene_Loc_4
#hntvlan554:Chromosome xiaqingzhao$ grep 'Y:' Gene_Loc_All > Gene_Loc_Y

##Then in excel, use text to column to seperate the start and end locations

###
Head<-read.table("~/Desktop/first RNAseq paper/Graphs/Graph_Head", header=T) 
Ovary<-read.table("~/Desktop/first RNAseq paper/Graphs/Graph_Ovary", header=T) 

Loc_2L<-read.table("~/Desktop/first RNAseq paper/Chromosome/Gene_Loc_2L", header=T) 
Loc_2R<-read.table("~/Desktop/first RNAseq paper/Chromosome/Gene_Loc_2R", header=T) 
Loc_3L<-read.table("~/Desktop/first RNAseq paper/Chromosome/Gene_Loc_3L", header=T) 
Loc_3R<-read.table("~/Desktop/first RNAseq paper/Chromosome/Gene_Loc_3R", header=T) 
Loc_X<-read.table("~/Desktop/first RNAseq paper/Chromosome/Gene_Loc_X", header=T) 
#Loc_Y<-read.table("~/Desktop/first RNAseq paper/Chromosome/Gene_Loc_Y", header=T) 
#Loc_4<-read.table("~/Desktop/first RNAseq paper/Chromosome/Gene_Loc_4", header=T) 

###### 
##Match EBSeq result with gene location 
Head_2L<-Head[Head$Gene %in% Loc_2L$Gene,]
Loc2L<-Loc_2L[match(Head_2L$Gene, Loc_2L$Gene),]
write.table(cbind(Head_2L, Loc2L), "Head_2L", quote=F, sep="\t", row.names=F) 

Ovary_2L<-Ovary[Ovary$Gene %in% Loc_2L$Gene,]
Loc2L<-Loc_2L[match(Ovary_2L$Gene, Loc_2L$Gene),]
write.table(cbind(Ovary_2L, Loc2L), "Ovary_2L", quote=F, sep="\t", row.names=F) 


Head_2R<-Head[Head$Gene %in% Loc_2R$Gene,]
Loc2R<-Loc_2R[match(Head_2R$Gene, Loc_2R$Gene),]
write.table(cbind(Head_2R, Loc2R), "Head_2R", quote=F, sep="\t", row.names=F) 

Ovary_2R<-Ovary[Ovary$Gene %in% Loc_2R$Gene,]
Loc2R<-Loc_2R[match(Ovary_2R$Gene, Loc_2R$Gene),]
write.table(cbind(Ovary_2R, Loc2R), "Ovary_2R", quote=F, sep="\t", row.names=F)


Head_3L<-Head[Head$Gene %in% Loc_3L$Gene,]
Loc3L<-Loc_3L[match(Head_3L$Gene, Loc_3L$Gene),]
write.table(cbind(Head_3L, Loc3L), "Head_3L", quote=F, sep="\t", row.names=F) 

Ovary_3L<-Ovary[Ovary$Gene %in% Loc_3L$Gene,]
Loc3L<-Loc_3L[match(Ovary_3L$Gene, Loc_3L$Gene),]
write.table(cbind(Ovary_3L, Loc3L), "Ovary_3L", quote=F, sep="\t", row.names=F) 


Head_3R<-Head[Head$Gene %in% Loc_3R$Gene,]
Loc3R<-Loc_3R[match(Head_3R$Gene, Loc_3R$Gene),]
write.table(cbind(Head_3R, Loc3R), "Head_3R", quote=F, sep="\t", row.names=F) 

Ovary_3R<-Ovary[Ovary$Gene %in% Loc_3R$Gene,]
Loc3R<-Loc_3R[match(Ovary_3R$Gene, Loc_3R$Gene),]
write.table(cbind(Ovary_3R, Loc3R), "Ovary_3R", quote=F, sep="\t", row.names=F) 


Head_X<-Head[Head$Gene %in% Loc_X$Gene,]
LocX<-Loc_X[match(Head_X$Gene, Loc_X$Gene),]
write.table(cbind(Head_X, LocX), "Head_X", quote=F, sep="\t", row.names=F) 

Ovary_X<-Ovary[Ovary$Gene %in% Loc_X$Gene,]
LocX<-Loc_X[match(Ovary_X$Gene, Loc_X$Gene),]
write.table(cbind(Ovary_X, LocX), "Ovary_X", quote=F, sep="\t", row.names=F) 



##########################################################################################
par(mfrow=c(1,2))

Head_2L<-Head[Head$Gene %in% Loc_2L$Gene,]
Loc2L<-Loc_2L[match(Head_2L$Gene, Loc_2L$Gene),3]
Head_2L<-cbind(Head_2L, Loc2L)

plot(x=Head_2L$Loc2L[Head_2L$D_head_norm>Head_2L$ND_head_norm], y=Head_2L$PPEE[Head_2L$D_head_norm>Head_2L$ND_head_norm], type="p", main="Head_Chromosome 2L", xlab="Chromosome Location", ylab="p value", pch=19, col=rgb(0,0,1,0.6), cex=0.2) 
points(x=Head_2L$Loc2L[Head_2L$D_head_norm<Head_2L$ND_head_norm], y=Head_2L$PPEE[Head_2L$D_head_norm<Head_2L$ND_head_norm], type="p", pch=19, col=rgb(1,0,0,0.6), cex=0.2)
abline(0.05,0,col="black",lwd=1) 



Ovary_2L<-Ovary[Ovary$Gene %in% Loc_2L$Gene,]
Loc2L<-Loc_2L[match(Ovary_2L$Gene, Loc_2L$Gene),3]
Ovary_2L<-cbind(Ovary_2L, Loc2L)

plot(x=Ovary_2L$Loc2L[Ovary_2L$D_ovary_norm>Ovary_2L$ND_ovary_norm], y=Ovary_2L$PPEE[Ovary_2L$D_ovary_norm>Ovary_2L$ND_ovary_norm], type="p", main="Ovary_Chromosome 2L", xlab="Chromosome Location", ylab="p value", pch=19, col=rgb(0,0,1,0.6), cex=0.2) 
points(x=Ovary_2L$Loc2L[Ovary_2L$D_ovary_norm<Ovary_2L$ND_ovary_norm], y=Ovary_2L$PPEE[Ovary_2L$D_ovary_norm<Ovary_2L$ND_ovary_norm], type="p", pch=19, col=rgb(1,0,0,0.6), cex=0.2)
abline(0.05,0,col="black",lwd=1) 

###

par(mfrow=c(1,2))

Head_2R<-Head[Head$Gene %in% Loc_2R$Gene,]
Loc2R<-Loc_2R[match(Head_2R$Gene, Loc_2R$Gene),3]
Head_2R<-cbind(Head_2R, Loc2R)

plot(x=Head_2R$Loc2R[Head_2R$D_head_norm>Head_2R$ND_head_norm], y=Head_2R$PPEE[Head_2R$D_head_norm>Head_2R$ND_head_norm], type="p", main="Head_Chromosome 2R", xlab="Chromosome Location", ylab="p value", pch=19, col=rgb(0,0,1,0.6), cex=0.2) 
points(x=Head_2R$Loc2R[Head_2R$D_head_norm<Head_2R$ND_head_norm], y=Head_2R$PPEE[Head_2R$D_head_norm<Head_2R$ND_head_norm], type="p", pch=19, col=rgb(1,0,0,0.6), cex=0.2)
abline(0.05,0,col="black",lwd=1) 



Ovary_2R<-Ovary[Ovary$Gene %in% Loc_2R$Gene,]
Loc2R<-Loc_2R[match(Ovary_2R$Gene, Loc_2R$Gene),3]
Ovary_2R<-cbind(Ovary_2R, Loc2R)

plot(x=Ovary_2R$Loc2R[Ovary_2R$D_ovary_norm>Ovary_2R$ND_ovary_norm], y=Ovary_2R$PPEE[Ovary_2R$D_ovary_norm>Ovary_2R$ND_ovary_norm], type="p", main="Ovary_Chromosome 2R", xlab="Chromosome Location", ylab="p value", pch=19, col=rgb(0,0,1,0.6), cex=0.2) 
points(x=Ovary_2R$Loc2R[Ovary_2R$D_ovary_norm<Ovary_2R$ND_ovary_norm], y=Ovary_2R$PPEE[Ovary_2R$D_ovary_norm<Ovary_2R$ND_ovary_norm], type="p", pch=19, col=rgb(1,0,0,0.6), cex=0.2)
abline(0.05,0,col="black",lwd=1) 

###

par(mfrow=c(1,2))

Head_3L<-Head[Head$Gene %in% Loc_3L$Gene,]
Loc3L<-Loc_3L[match(Head_3L$Gene, Loc_3L$Gene),3]
Head_3L<-cbind(Head_3L, Loc3L)

plot(x=Head_3L$Loc3L[Head_3L$D_head_norm>Head_3L$ND_head_norm], y=Head_3L$PPEE[Head_3L$D_head_norm>Head_3L$ND_head_norm], type="p", main="Head_Chromosome 3L", xlab="Chromosome Location", ylab="p value", pch=19, col=rgb(0,0,1,0.6), cex=0.2) 
points(x=Head_3L$Loc3L[Head_3L$D_head_norm<Head_3L$ND_head_norm], y=Head_3L$PPEE[Head_3L$D_head_norm<Head_3L$ND_head_norm], type="p", pch=19, col=rgb(1,0,0,0.6), cex=0.2)
abline(0.05,0,col="black",lwd=1) 



Ovary_3L<-Ovary[Ovary$Gene %in% Loc_3L$Gene,]
Loc3L<-Loc_3L[match(Ovary_3L$Gene, Loc_3L$Gene),3]
Ovary_3L<-cbind(Ovary_3L, Loc3L)

plot(x=Ovary_3L$Loc3L[Ovary_3L$D_ovary_norm>Ovary_3L$ND_ovary_norm], y=Ovary_3L$PPEE[Ovary_3L$D_ovary_norm>Ovary_3L$ND_ovary_norm], type="p", main="Ovary_Chromosome 3L", xlab="Chromosome Location", ylab="p value", pch=19, col=rgb(0,0,1,0.6), cex=0.2) 
points(x=Ovary_3L$Loc3L[Ovary_3L$D_ovary_norm<Ovary_3L$ND_ovary_norm], y=Ovary_3L$PPEE[Ovary_3L$D_ovary_norm<Ovary_3L$ND_ovary_norm], type="p", pch=19, col=rgb(1,0,0,0.6), cex=0.2)
abline(0.05,0,col="black",lwd=1) 

###
par(mfrow=c(1,2))

Head_3R<-Head[Head$Gene %in% Loc_3R$Gene,]
Loc3R<-Loc_3R[match(Head_3R$Gene, Loc_3R$Gene),3]
Head_3R<-cbind(Head_3R, Loc3R)

plot(x=Head_3R$Loc3R[Head_3R$D_head_norm>Head_3R$ND_head_norm], y=Head_3R$PPEE[Head_3R$D_head_norm>Head_3R$ND_head_norm], type="p", main="Head_Chromosome 3R", xlab="Chromosome Location", ylab="p value", pch=19, col=rgb(0,0,1,0.6), cex=0.2) 
points(x=Head_3R$Loc3R[Head_3R$D_head_norm<Head_3R$ND_head_norm], y=Head_3R$PPEE[Head_3R$D_head_norm<Head_3R$ND_head_norm], type="p", pch=19, col=rgb(1,0,0,0.6), cex=0.2)
abline(0.05,0,col="black",lwd=1) 



Ovary_3R<-Ovary[Ovary$Gene %in% Loc_3R$Gene,]
Loc3R<-Loc_3R[match(Ovary_3R$Gene, Loc_3R$Gene),3]
Ovary_3R<-cbind(Ovary_3R, Loc3R)

plot(x=Ovary_3R$Loc3R[Ovary_3R$D_ovary_norm>Ovary_3R$ND_ovary_norm], y=Ovary_3R$PPEE[Ovary_3R$D_ovary_norm>Ovary_3R$ND_ovary_norm], type="p", main="Ovary_Chromosome 3R", xlab="Chromosome Location", ylab="p value", pch=19, col=rgb(0,0,1,0.6), cex=0.2) 
points(x=Ovary_3R$Loc3R[Ovary_3R$D_ovary_norm<Ovary_3R$ND_ovary_norm], y=Ovary_3R$PPEE[Ovary_3R$D_ovary_norm<Ovary_3R$ND_ovary_norm], type="p", pch=19, col=rgb(1,0,0,0.6), cex=0.2)
abline(0.05,0,col="black",lwd=1) 

### 

par(mfrow=c(1,2))

Head_X<-Head[Head$Gene %in% Loc_X$Gene,]
LocX<-Loc_X[match(Head_X$Gene, Loc_X$Gene),3]
Head_X<-cbind(Head_X, LocX)

plot(x=Head_X$LocX[Head_X$D_head_norm>Head_X$ND_head_norm], y=Head_X$PPEE[Head_X$D_head_norm>Head_X$ND_head_norm], type="p", main="Head_Chromosome X", xlab="Chromosome Location", ylab="p value", pch=19, col=rgb(0,0,1,0.6), cex=0.2) 
points(x=Head_X$LocX[Head_X$D_head_norm<Head_X$ND_head_norm], y=Head_X$PPEE[Head_X$D_head_norm<Head_X$ND_head_norm], type="p", pch=19, col=rgb(1,0,0,0.6), cex=0.2)
abline(0.05,0,col="black",lwd=1) 



Ovary_X<-Ovary[Ovary$Gene %in% Loc_X$Gene,]
LocX<-Loc_X[match(Ovary_X$Gene, Loc_X$Gene),3]
Ovary_X<-cbind(Ovary_X, LocX)

plot(x=Ovary_X$LocX[Ovary_X$D_ovary_norm>Ovary_X$ND_ovary_norm], y=Ovary_X$PPEE[Ovary_X$D_ovary_norm>Ovary_X$ND_ovary_norm], type="p", main="Ovary_Chromosome X", xlab="Chromosome Location", ylab="p value", pch=19, col=rgb(0,0,1,0.6), cex=0.2) 
points(x=Ovary_X$LocX[Ovary_X$D_ovary_norm<Ovary_X$ND_ovary_norm], y=Ovary_X$PPEE[Ovary_X$D_ovary_norm<Ovary_X$ND_ovary_norm], type="p", pch=19, col=rgb(1,0,0,0.6), cex=0.2)
abline(0.05,0,col="black",lwd=1) 

###
##Chromosome Y and 4 has too few genes on them therefore are ignored. 
