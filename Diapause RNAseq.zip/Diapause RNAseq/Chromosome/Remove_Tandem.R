##Lable tandemly arrayed duplicated genes

Tan<-read.table("YoungTandem.txt", header=T) 
AllTan<-read.table("Tandem.txt", header=T) 

data<-read.table("Head_2L", header=T) #Change file names as wanted 

n<-length(data$Gene)
NotTan<-rep(NA, n) 
NotAllTan<-rep(NA, n) 

for (i in 1:n) {
	if (data$Gene[i] %in% Tan$GeneID) {NotTan[i]<-F} else {
		{NotTan[i]<-T} 
	}
}

for (i in 1:n) {
	if (data$Gene[i] %in% AllTan$GeneID) {NotAllTan[i]<-F} else {
		{NotAllTan[i]<-T} 
	}
} 

write.table(cbind(NotTan, NotAllTan), file="temp.txt", quote=F, sep="\t", row.names=F) 

##Calculate spatial autocorrelation 

library(ape) 

data<-read.table("Ovary_X", header=T) 
data<-data[data$NotAllTan==T,]

dists<-as.matrix(dist(cbind(data$Start, rep(0, length(data$Gene))))) 
dists.inv<-1/dists 
diag(dists.inv)<-0 
dists.inv[is.infinite(dists.inv)] <- 0
Moran.I(data$log2FC, dists.inv) 


##Resampling to generate null of spatial autocorrelation 

library(ape) 

data<-read.table("Head_2L", header=T) 
data<-data[data$NotAllTan==T,]

resampling<-1000  

FakeMoranI<-rep(NA, resampling)

for (i in 1:resampling) {
	fakeStart<-sample(data$Start, length(data$Start), replace=F) 
	dists<-as.matrix(dist(cbind(fakeStart, rep(0, length(data$Gene))))) 
	dists.inv<-1/dists 
	diag(dists.inv)<-0 
	dists.inv[is.infinite(dists.inv)] <- 0
	output<-Moran.I(data$log2FC, dists.inv) 
	FakeMoranI[i]<-output$observed
} 

write.table(FakeMoranI, "temp.txt", quote=F, sep="\n", row.names=F, col.names=F) 


##Facet Graph 

#Fake Moran's I 

FMI<-read.table("FakeMoranI_TandemRemoved.txt", header=T) 

#Real Moran's I 

RMI<-read.table("Log2_MoranI_TandemRemoved.txt", header=T) 

library(ggplot2) 

p<-ggplot(FMI, aes(x=FakeMoranI))+geom_density()+geom_vline(aes(xintercept=Observed), data=RMI, col="black")+facet_grid(Tissue~Chrom)+xlim(-0.08, 0.14)+xlab("Moran's I")+theme_bw()



