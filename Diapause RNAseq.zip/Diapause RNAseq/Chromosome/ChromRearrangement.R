data<-read.table("Ovary_2L", header=T)  ##Change file name to change tissue and chromosome. 

size<-3  ##Change value to change window size. 

x<-as.numeric(data[,5])

location<-order(data[,9])

x_ordered<-x[location]

result<-rep(NA, length(x_ordered))

for(i in 1:length(x_ordered)){
  #result[i]<-mean(x_ordered[max(i-size, 0):min(i+size, length(x_ordered))])	
  neighbour<-max(i-size, 1):min(i+size, length(x_ordered)) 
  neighbour<-neighbour[neighbour!=i] 
  result[i]<-mean(x_ordered[neighbour])
}


mean(result[x_ordered==1])
sd(result[x_ordered==1])

mean(result[x_ordered==0])
sd(result[x_ordered==0])

plot(density(result[x_ordered==1], kernel = "gaussian"), xlim=c(0, 1), ylim=c(0, 10), col="red")
par(new=T)
plot(density(result[x_ordered==0], kernel = "gaussian"), xlim=c(0, 1), ylim=c(0, 10), col="blue")

t.test(result[x_ordered==1], result[x_ordered==0], alternative="greater") 

########################################################################################

##Adjusted p values 

Chrom<-read.table("ChromosomeRearrangement.txt", header=T) 

adj_p<-p.adjust(Chrom$t_test_p, method="BH", n=length(Chrom$t_test_p)) 

write.table(cbind(Chrom, adj_p), file="Chromosome_Rearrangement", quote=F, sep="\t", row.names=F) 

########################################################################################

##Plots 

Chrom<-read.table("Chromosome_Rearrangement", header=T) 

attach(Chrom) 

library(gplots)

par(mfrow=c(2,3))

plotCI(x=WindowSize[Tissue=="Head" & Chromosome=="2L"], y=DE_mean[Tissue=="Head" & Chromosome=="2L"], type="o", gap=0, pch=17, col="red", xlab="Window Size", ylim=c(0,0.4), ylab="Proportion of DE genes", main="Chromosome 2L") 

plotCI(x=WindowSize[Tissue=="Head" & Chromosome=="2L"], y=EE_mean[Tissue=="Head" & Chromosome=="2L"], type="o", gap=0, pch=15, col="red", add=T)

plotCI(x=WindowSize[Tissue=="Ovary" & Chromosome=="2L"], y=DE_mean[Tissue=="Ovary" & Chromosome=="2L"], type="o", gap=0, pch=17, col="green", add=T) 

plotCI(x=WindowSize[Tissue=="Ovary" & Chromosome=="2L"], y=EE_mean[Tissue=="Ovary" & Chromosome=="2L"], type="o", gap=0, pch=15, col="green", add=T) 

legend("topright", c("Head DE", "Head EE", "Ovary DE", "Ovary EE"), col=c("red", "red", "green", "green"), pch=c(17, 15, 17, 15)) 

### 

plotCI(x=WindowSize[Tissue=="Head" & Chromosome=="2R"], y=DE_mean[Tissue=="Head" & Chromosome=="2R"], type="o", gap=0, pch=17, col="red", xlab="Window Size", ylim=c(0,0.4), ylab="Proportion of DE genes", main="Chromosome 2R") 

plotCI(x=WindowSize[Tissue=="Head" & Chromosome=="2R"], y=EE_mean[Tissue=="Head" & Chromosome=="2R"], type="o", gap=0, pch=15, col="red", add=T)

plotCI(x=WindowSize[Tissue=="Ovary" & Chromosome=="2R"], y=DE_mean[Tissue=="Ovary" & Chromosome=="2R"], type="o", gap=0, pch=17, col="green", add=T) 

plotCI(x=WindowSize[Tissue=="Ovary" & Chromosome=="2R"], y=EE_mean[Tissue=="Ovary" & Chromosome=="2R"], type="o", gap=0, pch=15, col="green", add=T) 

legend("topright", c("Head DE", "Head EE", "Ovary DE", "Ovary EE"), col=c("red", "red", "green", "green"), pch=c(17, 15, 17, 15)) 

### 

plotCI(x=WindowSize[Tissue=="Head" & Chromosome=="3L"], y=DE_mean[Tissue=="Head" & Chromosome=="3L"], type="o", gap=0, pch=17, col="red", xlab="Window Size", ylim=c(0,0.4), ylab="Proportion of DE genes", main="Chromosome 3L") 

plotCI(x=WindowSize[Tissue=="Head" & Chromosome=="3L"], y=EE_mean[Tissue=="Head" & Chromosome=="3L"], type="o", gap=0, pch=15, col="red", add=T)

plotCI(x=WindowSize[Tissue=="Ovary" & Chromosome=="3L"], y=DE_mean[Tissue=="Ovary" & Chromosome=="3L"], type="o", gap=0, pch=17, col="green", add=T) 

plotCI(x=WindowSize[Tissue=="Ovary" & Chromosome=="3L"], y=EE_mean[Tissue=="Ovary" & Chromosome=="3L"], type="o", gap=0, pch=15, col="green", add=T) 

legend("topright", c("Head DE", "Head EE", "Ovary DE", "Ovary EE"), col=c("red", "red", "green", "green"), pch=c(17, 15, 17, 15)) 

### 

plotCI(x=WindowSize[Tissue=="Head" & Chromosome=="3R"], y=DE_mean[Tissue=="Head" & Chromosome=="3R"], type="o", gap=0, pch=17, col="red", xlab="Window Size", ylim=c(0,0.4), ylab="Proportion of DE genes", main="Chromosome 3R") 

plotCI(x=WindowSize[Tissue=="Head" & Chromosome=="3R"], y=EE_mean[Tissue=="Head" & Chromosome=="3R"], type="o", gap=0, pch=15, col="red", add=T)

plotCI(x=WindowSize[Tissue=="Ovary" & Chromosome=="3R"], y=DE_mean[Tissue=="Ovary" & Chromosome=="3R"], type="o", gap=0, pch=17, col="green", add=T) 

plotCI(x=WindowSize[Tissue=="Ovary" & Chromosome=="3R"], y=EE_mean[Tissue=="Ovary" & Chromosome=="3R"], type="o", gap=0, pch=15, col="green", add=T) 

legend("topright", c("Head DE", "Head EE", "Ovary DE", "Ovary EE"), col=c("red", "red", "green", "green"), pch=c(17, 15, 17, 15)) 

### 

plotCI(x=WindowSize[Tissue=="Head" & Chromosome=="X"], y=DE_mean[Tissue=="Head" & Chromosome=="X"], type="o", gap=0, pch=17, col="red", xlab="Window Size", ylim=c(0,0.4), ylab="Proportion of DE genes", main="Chromosome X") 

plotCI(x=WindowSize[Tissue=="Head" & Chromosome=="X"], y=EE_mean[Tissue=="Head" & Chromosome=="X"], type="o", gap=0, pch=15, col="red", add=T)

plotCI(x=WindowSize[Tissue=="Ovary" & Chromosome=="X"], y=DE_mean[Tissue=="Ovary" & Chromosome=="X"], type="o", gap=0, pch=17, col="green", add=T) 

plotCI(x=WindowSize[Tissue=="Ovary" & Chromosome=="X"], y=EE_mean[Tissue=="Ovary" & Chromosome=="X"], type="o", gap=0, pch=15, col="green", add=T) 

legend("topright", c("Head DE", "Head EE", "Ovary DE", "Ovary EE"), col=c("red", "red", "green", "green"), pch=c(17, 15, 17, 15)) 

detach(Chrom) 

###############################################################################################

##Autocorrelation 



