##Moran's I spatial autocorrelation 

library(ape) 

##Autocorrelation of log2FC values 
##https://stats.idre.ucla.edu/r/faq/how-can-i-calculate-morans-i-in-r/

Autocorrelation<-function(File) {
	data<-read.table(File, header=T) 
	dists<-as.matrix(dist(cbind(data$Start, rep(0, length(data$Gene))))) 
	dists.inv<-1/dists 
	diag(dists.inv)<-0 
	dists.inv[is.infinite(dists.inv)] <- 0
	Moran.I(data$log2FC, dists.inv) 
} 

#Or, 

Autocorrelation<-function(Data) {
	data<-Data 
	dists<-as.matrix(dist(cbind(data$Start, rep(0, length(data$Gene))))) 
	dists.inv<-1/dists 
	diag(dists.inv)<-0 
	dists.inv[is.infinite(dists.inv)] <- 0
	Moran.I(data$log2FC, dists.inv) 
} 


##Autocorrelation of DE 

Autocorrelation<-function(File) {
	data<-read.table(File, header=T) 
	dists<-as.matrix(dist(cbind(data$Start, rep(0, length(data$Gene))))) 
	dists.inv<-1/dists 
	diag(dists.inv)<-0 
	dists.inv[is.infinite(dists.inv)] <- 0
	Moran.I(as.numeric(data$DE), dists.inv) 
}


##Resampling of spatial autocorrelation 

data<-read.table("Ovary_3L", header=T) 

resampling<-500 

FakeMoranI<-rep(NA, resampling)

for (i in 1:resampling) {
	fakeStart<-sample(data$Start, length(data$Start), replace=F) 
	dists<-as.matrix(dist(cbind(fakeStart, rep(0, length(data$Gene))))) 
	dists.inv<-1/dists 
	diag(dists.inv)<-0 
	dists.inv[is.infinite(dists.inv)] <- 0
	output<-Moran.I(data$log2FC, dists.inv) 
	FakeMoranI[i]<-output$observed
} 

write.table(FakeMoranI, "Ovary_3L_bs", quote=F, sep="\n", row.names=F, col.names=F) 

###################### 

##Function_resampling of spatial autocorrelation 

# library(ape) 

# Resamp_Autocor<-function(File, resampling) {
	# data<-read.table(File, header=T) 
	# FakeMoranI<-rep(NA, resampling) 
	
	# for(i in 1:resampling) {
		# fakeStart<-sample(data$Start, length(data$Start), replace=F) 
		# dists<-as.matrix(dist(cbind(fakeStart, rep(0, length(data$Gene))))) 
		# dists.inv<-1/dists 
		# diag(dists.inv)<-0 
		# dists.inv[is.infinite(dists.inv)] <- 0
		# output<-Moran.I(data$log2FC, dists.inv) 
		# FakeMoranI[i]<-output$observed
	# } 
	
	# # dists<-as.matrix(dist(cbind(data$Start, rep(0, length(data$Gene))))) 
	# # dists.inv<-1/dists 
	# # diag(dists.inv)<-0 
	# # dists.inv[is.infinite(dists.inv)] <- 0
	# # RealMoranI<-Moran.I(data$log2FC, dists.inv) 
	
	# # plot(density(FakeMoranI, kernel = "gaussian"), xlim=c(-1,1)) 
	# # abline(v=RealMoranI$observed, col="red") 
	# #return(FakeMoranI) 
	# write.table(FakeMoranI, file=paste(File, "_FakeMoranI.txt"), quote=F, sep="\n", row.names=F)
# } 



