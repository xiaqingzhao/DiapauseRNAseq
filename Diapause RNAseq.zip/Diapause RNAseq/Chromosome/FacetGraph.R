#Fake Moran's I 

FMI<-read.table("FakeMoranI.txt", header=T) 

#Real Moran's I 

RMI<-read.table("log2FC_Autocorrelation.txt", header=T) 

library(ggplot2) 

p<-ggplot(FMI, aes(x=FakeMoranI))+geom_density()+geom_vline(aes(xintercept=Observed), data=RMI, col="red")+facet_grid(Tissue~Chrom)+xlim(-0.08, 0.12)+xlab("Moran's I")


