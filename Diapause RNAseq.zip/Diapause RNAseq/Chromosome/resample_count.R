data<-read.table("Ovary_3L", header=T) 

fakeStart<-sample(data$Start, length(data$Start), replace=F) 

size<-3  ##Change value to change window size. 

x<-as.numeric(data[,5])

location<-order(fakeStart)

x_ordered<-x[location]

result<-rep(NA, length(x_ordered)) 

for(i in 1:length(x_ordered)){
  #result[i]<-mean(x_ordered[max(i-size, 0):min(i+size, length(x_ordered))])	
  neighbour<-max(i-size, 1):min(i+size, length(x_ordered)) 
  neighbour<-neighbour[neighbour!=i] 
  result[i]<-mean(x_ordered[neighbour])
}


mean(result[x_ordered==1])
sd(result[x_ordered==1])

mean(result[x_ordered==0])
sd(result[x_ordered==0])

plot(density(result[x_ordered==1], kernel = "gaussian"), xlim=c(0, 1), ylim=c(0, 10), col="red")
par(new=T)
plot(density(result[x_ordered==0], kernel = "gaussian"), xlim=c(0, 1), ylim=c(0, 10), col="blue")

t.test(result[x_ordered==1], result[x_ordered==0], alternative="greater") 

