##Sliding window 

ChromSlidingWindow<-function(File, windowsize) { 
	data<-read.table(File, header=T)   

	de<-as.numeric(data[,5])

	location<-order(data[,9])

	de_ordered<-de[location] 

	n<-length(de_ordered) 

	starts<-seq(1,n,by=windowsize) 

	m<-length(starts) 
	
	mean<-rep(NA,m)
	for(i in 1:m) {
		if(i<m) {
			mean[i]<-mean(de_ordered[starts[i]:(starts[i]+(windowsize-1))]) 
		} else {
			mean[i]<-mean(de_ordered[starts[i]:n])
		}
	
	} 
	
	plot(starts, mean, type="p", ylim=c(0,1), main=File, xlab="Chromosome Location", ylab="Proportion of DE Genes") 
	abline(mean(de_ordered), 0) 
	print(mean) 
	#write.table(data[location,], file=paste(File, "_ordered"), quote=F, sep="\t", row.names=F) 
} 