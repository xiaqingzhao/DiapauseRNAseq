#! /usr/bin/env python
InFileName=raw_input("File Name:")

InFile=open(InFileName, 'r')

OutFileName=InFileName+"_Command" 

OutFile=open(OutFileName, 'w') 

for Line in InFile: 
	Line=Line.strip('\n') 
	ElementList=Line.split('\t') 
	OutputString='java -jar ~/snpEff_3_1/SnpSift.jar filter "(CQ<=0.1) & (USED=\'TRUE\') & (EFF[*].GENE=\'%s\')" -f 6d_v7.3_output.vcf | awk -f vcf_conv.awk | grep -v "^#" >> Temp'  % (ElementList[1]) 
	#print OutputString 
	OutFile.write(OutputString+"\n") 

InFile.close()
OutFile.close()