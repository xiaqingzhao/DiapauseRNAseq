Clinal<-read.table("Clinal_Slope.txt", header=T) 

latitude<-c(25.5,25.5,30.9,33,35.5,45.5,45.5) 

n<-nrow(Clinal) 

reg<-list()
slope<-rep(NA,n) 
absslope<-rep(NA,n)
p<-rep(NA,n)

for (i in 1:n) {
	freq<-rbind(Clinal[i,7], Clinal[i,8], Clinal[i,9], Clinal[i,10], Clinal[i,11], Clinal[i,12], Clinal[i,13]) 
	weight<-rbind(Clinal[i,14], Clinal[i,15], Clinal[i,16], Clinal[i,17], Clinal[i,18], Clinal[i,19], Clinal[i,20])
	reg<-glm(freq~latitude, family=binomial, weights=weight) 
	slope[i]<-reg$coefficients[2] 
	absslope[i]<-abs(slope[i])
	p[i]<-coef(summary(reg))[2,4]
}

write.table(cbind(Clinal, slope, absslope,p), file="ClinalSlopeResult.txt", quote=F, sep="\t", row.names=F) 

#################### 

Seasonal<-read.table("Seasonal_Slope.txt", header=T) 

season<-c(0,1,0,1,0,1) 

n<-nrow(Seasonal) 

reg<-list() 

slope<-rep(NA, n) 
absslope<-rep(NA, n) 
p<-rep(NA,n) 

for (i in 1:n) {
	freq<-rbind(Seasonal[i,7], Seasonal[i,8], Seasonal[i,9], Seasonal[i,10], Seasonal[i,11], Seasonal[i,12]) 
	weight<-rbind(Seasonal[i,14], Seasonal[i,15], Seasonal[i,16], Seasonal[i,17], Seasonal[i,18], Seasonal[i,19])
	reg<-glm(freq~season, family=binomial, weights=weight) 
	slope[i]<-reg$coefficients[2] 
	absslope[i]<-abs(slope[i])
	p[i]<-coef(summary(reg))[2,4]
}

write.table(cbind(Seasonal, slope, absslope,p), file="SeasonalSlopeResult.txt", quote=F, sep="\t", row.names=F) 
