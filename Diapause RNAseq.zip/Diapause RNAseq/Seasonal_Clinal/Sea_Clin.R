Seasonal<-scan("Seasonal", what="") 
Clinal<-scan("Clinal", what="") 

Head<-read.table("~/Desktop/first RNAseq paper/Graphs/Graph_Head", header=T)


attach(Head) 

Sea<-Gene %in% Seasonal 

#summary(Sea)
#   Mode   FALSE    TRUE    NA's 
#logical   10506    1698       0 

a=2.5
b=50000 

N<-nrow(Head) 
graph_log2FC<-rep(NA,N)
graph_mean_RPKM<-rep(NA,N)

for(i in 1:N) {
	if(log2FC[i]>a) {
		graph_log2FC[i]=a
	} else if(log2FC[i]<a*(-1)) {
		graph_log2FC[i]<-a*(-1)
	} else {graph_log2FC[i]<-log2FC[i]}
} 

for(i in 1:N) {
	if(mean_RPKM[i]>b) {
		graph_mean_RPKM[i]=b
	} else {graph_mean_RPKM[i]<-mean_RPKM[i]}
}

plot(x=graph_mean_RPKM[DE==F & Sea==F], y=graph_log2FC[DE==F & Sea==F], type="p", main="Head", xlim=c(0,b), ylim=c(-a,a), xlab="Mean Normalized RPKM", ylab="log2 Fold Change (D over ND)", pch=19, col=rgb(0,0,0,0.15), cex=0.2) 

points(x=graph_mean_RPKM[DE==T & Sea==F], y=graph_log2FC[DE==T & Sea==F], pch=19, col=rgb(1,0,0,0.15), cex=0.2) 

points(x=graph_mean_RPKM[DE==F & Sea==T], y=graph_log2FC[DE==F & Sea==T], pch=22, col="medium blue", cex=0.4)

points(x=graph_mean_RPKM[DE==T & Sea==T], y=graph_log2FC[DE==T & Sea==T], pch=22, col="deep pink", cex=0.4)

abline(0,0,col=rgb(0,0,0,0.5),lwd=1.5) 

legend("bottomright", c("Seasonal Gene, DE", "Seasonal Gene, not DE"), col=c("deep pink", "medium blue"), pch=c(22, 22))

detach(Head) 

####

attach(Head) 

Cli<-Gene %in% Clinal 

#summary(Cli) #q<0.1
#   Mode   FALSE    TRUE    NA's 
#logical    1774   10430       0 

#summary(Cli) #q<0.01
#   Mode   FALSE    TRUE    NA's 
#logical    4736    7468       0 

a=2.5
b=50000 

N<-nrow(Head) 
graph_log2FC<-rep(NA,N)
graph_mean_RPKM<-rep(NA,N)

for(i in 1:N) {
	if(log2FC[i]>a) {
		graph_log2FC[i]=a
	} else if(log2FC[i]<a*(-1)) {
		graph_log2FC[i]<-a*(-1)
	} else {graph_log2FC[i]<-log2FC[i]}
} 

for(i in 1:N) {
	if(mean_RPKM[i]>b) {
		graph_mean_RPKM[i]=b
	} else {graph_mean_RPKM[i]<-mean_RPKM[i]}
}

plot(x=graph_mean_RPKM[DE==F & Cli==F], y=graph_log2FC[DE==F & Cli==F], type="p", main="Head", xlim=c(0,b), ylim=c(-a,a), xlab="Mean Normalized RPKM", ylab="log2 Fold Change (D over ND)", pch=19, col=rgb(0,0,0,0.15), cex=0.2) 

points(x=graph_mean_RPKM[DE==T & Cli==F], y=graph_log2FC[DE==T & Cli==F], pch=19, col=rgb(1,0,0,0.15), cex=0.2) 

points(x=graph_mean_RPKM[DE==F & Cli==T], y=graph_log2FC[DE==F & Cli==T], pch=22, col="medium blue", cex=0.4)

points(x=graph_mean_RPKM[DE==T & Cli==T], y=graph_log2FC[DE==T & Cli==T], pch=22, col="deep pink", cex=0.4)

abline(0,0,col=rgb(0,0,0,0.5),lwd=1.5) 

legend("bottomright", c("Clinal Gene, DE", "Clinal Gene, not DE"), col=c("deep pink", "medium blue"), pch=c(22, 22))

detach(Head) 


#############################################################################################

Ovary<-read.table("~/Desktop/first RNAseq paper/Graphs/Graph_Ovary", header=T) 


attach(Ovary) 

Sea<-Gene %in% Seasonal 

#summary(Sea)
#   Mode   FALSE    TRUE    NA's 
#logical    9387    1469       0 

a=2.5
b=50000 

N<-nrow(Ovary) 
graph_log2FC<-rep(NA,N)
graph_mean_RPKM<-rep(NA,N)

for(i in 1:N) {
	if(log2FC[i]>a) {
		graph_log2FC[i]=a
	} else if(log2FC[i]<a*(-1)) {
		graph_log2FC[i]<-a*(-1)
	} else {graph_log2FC[i]<-log2FC[i]}
} 

for(i in 1:N) {
	if(mean_RPKM[i]>b) {
		graph_mean_RPKM[i]=b
	} else {graph_mean_RPKM[i]<-mean_RPKM[i]}
}

plot(x=graph_mean_RPKM[DE==F & Sea==F], y=graph_log2FC[DE==F & Sea==F], type="p", main="Ovary", xlim=c(0,b), ylim=c(-a,a), xlab="Mean Normalized RPKM", ylab="log2 Fold Change (D over ND)", pch=19, col=rgb(0,0,0,0.15), cex=0.2) 

points(x=graph_mean_RPKM[DE==T & Sea==F], y=graph_log2FC[DE==T & Sea==F], pch=19, col=rgb(1,0,0,0.15), cex=0.2) 

points(x=graph_mean_RPKM[DE==F & Sea==T], y=graph_log2FC[DE==F & Sea==T], pch=22, col="medium blue", cex=0.4)

points(x=graph_mean_RPKM[DE==T & Sea==T], y=graph_log2FC[DE==T & Sea==T], pch=22, col="deep pink", cex=0.4)

abline(0,0,col=rgb(0,0,0,0.5),lwd=1.5) 

legend("bottomright", c("Seasonal Gene, DE", "Seasonal Gene, not DE"), col=c("deep pink", "medium blue"), pch=c(22, 22))

detach(Ovary) 

####

attach(Ovary) 

Cli<-Gene %in% Clinal

#summary(Cli) #q<0.1 
#   Mode   FALSE    TRUE    NA's 
#logical    1657    9199       0 

#summary(Cli) #q<0.01
#   Mode   FALSE    TRUE    NA's 
#logical    4291    6565       0 

a=2.5
b=50000 

N<-nrow(Ovary) 
graph_log2FC<-rep(NA,N)
graph_mean_RPKM<-rep(NA,N)

for(i in 1:N) {
	if(log2FC[i]>a) {
		graph_log2FC[i]=a
	} else if(log2FC[i]<a*(-1)) {
		graph_log2FC[i]<-a*(-1)
	} else {graph_log2FC[i]<-log2FC[i]}
} 

for(i in 1:N) {
	if(mean_RPKM[i]>b) {
		graph_mean_RPKM[i]=b
	} else {graph_mean_RPKM[i]<-mean_RPKM[i]}
}

plot(x=graph_mean_RPKM[DE==F & Cli==F], y=graph_log2FC[DE==F & Cli==F], type="p", main="Ovary", xlim=c(0,b), ylim=c(-a,a), xlab="Mean Normalized RPKM", ylab="log2 Fold Change (D over ND)", pch=19, col=rgb(0,0,0,0.15), cex=0.2) 

points(x=graph_mean_RPKM[DE==T & Cli==F], y=graph_log2FC[DE==T & Cli==F], pch=19, col=rgb(1,0,0,0.15), cex=0.2) 

points(x=graph_mean_RPKM[DE==F & Cli==T], y=graph_log2FC[DE==F & Cli==T], pch=22, col="medium blue", cex=0.4)

points(x=graph_mean_RPKM[DE==T & Cli==T], y=graph_log2FC[DE==T & Cli==T], pch=22, col="deep pink", cex=0.4)

abline(0,0,col=rgb(0,0,0,0.5),lwd=1.5) 

legend("bottomright", c("Clinal Gene, DE", "Clinal Gene, not DE"), col=c("deep pink", "medium blue"), pch=c(22, 22))

detach(Ovary) 


###########################################################################################

##Some Numbers 

Head<-read.table("~/Desktop/first RNAseq paper/Graphs/Graph_Head", header=T)
Seasonal<-scan("Seasonal", what="") 
Clinal<-scan("Clinal", what="")

attach(Head) 

#Number of Genes that have higher/lower expression levels in D than in ND 
a<-Gene[D_head_norm>ND_head_norm] 
length(a) #6237

b<-Gene[D_head_norm<ND_head_norm]
length(b) #5967

#Number of Genes that have SIGNIFICANTLY higher/lower expression levels in D than in ND 
c<-Gene[D_head_norm>ND_head_norm & DE==T]
length(c) #510

d<-Gene[D_head_norm<ND_head_norm & DE==T]
length(d) #584

#Number of Seasonal Genes
length(Seasonal) #2070
#Number of Seasonal Genes that are tested in Head
length(intersect(Gene, Seasonal)) #1698

#Number of Genes that are up/down regulated that are seasonal genes 
length(intersect(a,Seasonal)) #782
length(intersect(b,Seasonal)) #916

#Number of Genes that are SIGNIFICANTLY up/down regulated that are seasonal genes 
length(intersect(c, Seasonal)) #54 
write.table(intersect(c, Seasonal), "High_Sea_Head", quote=F, sep="\n", row.names=F, col.names=F)
length(intersect(d,Seasonal)) #99
write.table(intersect(d, Seasonal), "Low_Sea_Head", quote=F, sep="\n", row.names=F, col.names=F)

#Number of Clinal Genes 
length(Clinal) #13021 #9294
#Number of Clinal Genes that are tested in Head
length(intersect(Gene, Clinal)) #10430 #7468

#Number of Genes that are up/down regulated that are clinal genes 
length(intersect(a,Clinal)) #5282 #3661
length(intersect(b,Clinal)) #5148 #3807

#Number of Genes that are SIGNIFICANTLY up/down regulated that are clinal genes 
length(intersect(c, Clinal)) #426 #289
write.table(intersect(c, Clinal), "High_Cli_Head", quote=F, sep="\n", row.names=F, col.names=F)
length(intersect(d,Clinal)) #491 #357
write.table(intersect(d, Clinal), "Low_Cli_Head", quote=F, sep="\n", row.names=F, col.names=F) 

#Number of genes that are differentially expressed and equally expressed 
length(Gene[DE==T]) #1094 
length(Gene[DE==F]) #11110 

#Number of genes that are DE/EE and are seasonal
length(intersect(Seasonal, Gene[DE==T])) #153
length(intersect(Seasonal, Gene[DE==F])) #1545 

#Number of genes that are DE/EE and are clinal
length(intersect(Clinal, Gene[DE==T])) #917 #646
length(intersect(Clinal, Gene[DE==F])) #9513 #6822

detach(Head)

#######

Ovary<-read.table("~/Desktop/first RNAseq paper/Graphs/Graph_Ovary", header=T) 
Seasonal<-scan("Seasonal", what="") 
Clinal<-scan("Clinal", what="")

attach(Ovary) 

#Number of Genes that have higher/lower expression levels in D than in ND 
a<-Gene[D_ovary_norm>ND_ovary_norm] 
length(a) #5272

b<-Gene[D_ovary_norm<ND_ovary_norm]
length(b) #5584

#Number of Genes that have SIGNIFICANTLY higher/lower expression levels in D than in ND 
c<-Gene[D_ovary_norm>ND_ovary_norm & DE==T]
length(c) #426

d<-Gene[D_ovary_norm<ND_ovary_norm & DE==T]
length(d) #747 

#Number of Seasonal Genes 
length(Seasonal) #2070
#Number of Seasonal Genes that are tested in Ovary
length(intersect(Gene, Seasonal)) #1469

#Number of Genes that are up/down regulated that are seasonal genes 
length(intersect(a,Seasonal)) #824
length(intersect(b,Seasonal)) #645 

#Number of Genes that are SIGNIFICANTLY up/down regulated that are seasonal genes 
length(intersect(c,Seasonal)) #87
write.table(intersect(c, Seasonal), "High_Sea_Ovary", quote=F, sep="\n", row.names=F, col.names=F)
length(intersect(d,Seasonal)) #75 
write.table(intersect(d, Seasonal), "Low_Sea_Ovary", quote=F, sep="\n", row.names=F, col.names=F)

#Number of Clinal Genes 
length(Clinal) #13021
#Number of Clinal Genes that are tested in Ovary
length(intersect(Gene, Clinal)) 9199

#Number of Genes that are up/down regulated that are clinal genes 
length(intersect(a,Clinal)) #4603 #3310
length(intersect(b,Clinal)) #4569 #3255

#Number of Genes that are SIGNIFICANTLY up/down regulated that are clinal genes 
length(intersect(c,Clinal)) #376 #279
write.table(intersect(c, Clinal), "High_Cli_Ovary", quote=F, sep="\n", row.names=F, col.names=F)
length(intersect(d,Clinal)) #550 #395 
write.table(intersect(d, Clinal), "Low_Cli_Ovary", quote=F, sep="\n", row.names=F, col.names=F)
detach(Ovary) 

#Number of genes that are differentially expressed and equally expressed 
length(Gene[DE==T]) #1173
length(Gene[DE==F]) #9683 

#Number of genes that are DE/EE and are seasonal
length(intersect(Seasonal, Gene[DE==T])) #162
length(intersect(Seasonal, Gene[DE==F])) #1307 

#Number of genes that are DE/EE and are clinal
length(intersect(Clinal, Gene[DE==T])) #926 #674 
length(intersect(Clinal, Gene[DE==F])) #8273 #5891  

