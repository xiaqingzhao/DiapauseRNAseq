##Combine RPKM values with fold change and p values for isoform data 

Head_Iso_RPKM<-read.table("reg_head.isoforms.cleaned.matrix", header=T) 
Head_Iso_Result<-read.table("isoform_head", header=T) 

a<-merge(Head_Iso_RPKM, Head_Iso_Result, by="Transcript")

write.table(a, "isoform_Head_result", quote=F, sep="\t", row.names=F) 

########

Ovary_Iso_RPKM<-read.table("reg_ovary.isoforms.cleaned.matrix", header=T) 
Ovary_Iso_Result<-read.table("isoform_ovary", header=T) 

b<-merge(Ovary_Iso_RPKM, Ovary_Iso_Result, by="Transcript")

write.table(b, "isoform_Ovary_result", quote=F, sep="\t", row.names=F) 

#############################################################################################

##Label genes with DE and not DE
HeadIso <- read.table("isoform_Head_result", header=T) 

N<-nrow(HeadIso) 

DE<-rep(NA,N)

for(i in 1:N) {
	if (HeadIso$PPEE[i]<=0.05) {
		DE[i]<-TRUE
	} else {DE[i]<-FALSE}
}

HeadIso<-cbind(HeadIso, DE)

write.table(HeadIso, file="isoform_Head_result", quote=F, sep="\t", row.names=F, col.names=T) 

###########

OvaryIso <- read.table("isoform_Ovary_result", header=T) 

N<-nrow(OvaryIso) 

DE<-rep(NA,N)

for(i in 1:N) {
	if (OvaryIso$PPEE[i]<=0.05) {
		DE[i]<-TRUE
	} else {DE[i]<-FALSE}
}

OvaryIso<-cbind(OvaryIso, DE)

write.table(OvaryIso, file="isoform_Ovary_result", quote=F, sep="\t", row.names=F, col.names=T) 

#############################################################################################

###Match gene ID with each transcript 

HeadIso<-read.table("isoform_Head_result", header=T) 
ID<-read.table("ID_Conversion", header=T) 

a<-merge(HeadIso, ID, by="Transcript") 

write.table(a, file="isoform_Head_result", quote=F, sep="\t", row.names=F, col.names=T) 

###

OvaryIso<-read.table("isoform_Ovary_result", header=T) 
ID<-read.table("ID_Conversion", header=T) 

b<-merge(OvaryIso, ID, by="Transcript") 

write.table(b, file="isoform_Ovary_result", quote=F, sep="\t", row.names=F, col.names=T) 

#############################################################################################

##Subsetting for DE isoforms 

HeadIso<-read.table("isoform_Head_result", header=T)

DE_HeadIso<-subset(HeadIso, HeadIso$DE==T, select=c(Transcript, D_head, ND_head, PPEE, RealFC, Gene))

write.table(DE_HeadIso, "DE_Head_Isoform", quote=F, sep="\t", row.names=F, col.names=T) 

#####

OvaryIso<-read.table("isoform_Ovary_result", header=T)

DE_OvaryIso<-subset(OvaryIso, OvaryIso$DE==T, select=c(Transcript, D_ovary, ND_ovary, PPEE, RealFC, Gene))

write.table(DE_OvaryIso, "DE_Ovary_Isoform", quote=F, sep="\t", row.names=F, col.names=T) 

######

DE_Head<-read.table("DE_Head_Isoform", header=T) 
High_D_Head_Iso<-subset(DE_Head, DE_Head$D_head>DE_Head$ND_head, select=c(Transcript, D_head, ND_head, PPEE, RealFC, Gene)) 
write.table(High_D_Head_Iso, "High_D_Head_Iso", quote=F, sep="\t", row.names=F, col.names=T) ## 1598 isoforms 

Low_D_Head_Iso<-subset(DE_Head, DE_Head$D_head<DE_Head$ND_head, select=c(Transcript, D_head, ND_head, PPEE, RealFC, Gene)) 
write.table(Low_D_Head_Iso, "Low_D_Head_Iso", quote=F, sep="\t", row.names=F, col.names=T)  ## 2164 isoforms  

###

DE_Ovary<-read.table("DE_Ovary_Isoform", header=T) 
High_D_Ovary_Iso<-subset(DE_Ovary, DE_Ovary$D_ovary>DE_Ovary$ND_ovary, select=c(Transcript, D_ovary, ND_ovary, PPEE, RealFC, Gene)) 
write.table(High_D_Ovary_Iso, "High_D_Ovary_Iso", quote=F, sep="\t", row.names=F, col.names=T) ## 1784 isoforms 

Low_D_Ovary_Iso<-subset(DE_Ovary, DE_Ovary$D_ovary<DE_Ovary$ND_ovary, select=c(Transcript, D_ovary, ND_ovary, PPEE, RealFC, Gene)) 
write.table(Low_D_Ovary_Iso, "Low_D_Ovary_Iso", quote=F, sep="\t", row.names=F, col.names=T) ## 1819 isoforms 

#############################################################################################

##Genes involved in each list 

High_D_Head_Iso_sorted<-sort(High_D_Head_Iso$Gene) 
High_D_Head_Iso_Genes<-unique(High_D_Head_Iso_sorted) ## 1384 genes 
write.table(High_D_Head_Iso_Genes, "High_D_Head_Iso_Genes", quote=F, sep="\n", row.names=F, col.names=F)

Low_D_Head_Iso_sorted<-sort(Low_D_Head_Iso$Gene) 
Low_D_Head_Iso_Genes<-unique(Low_D_Head_Iso_sorted) ## 1705 genes 
write.table(Low_D_Head_Iso_Genes, "Low_D_Head_Iso_Genes", quote=F, sep="\n", row.names=F, col.names=F)

#######

High_D_Ovary_Iso_sorted<-sort(High_D_Ovary_Iso$Gene) 
High_D_Ovary_Iso_Genes<-unique(High_D_Ovary_Iso_sorted) ## 1407 genes 
write.table(High_D_Ovary_Iso_Genes, "High_D_Ovary_Iso_Genes", quote=F, sep="\n", row.names=F, col.names=F)

Low_D_Ovary_Iso_sorted<-sort(Low_D_Ovary_Iso$Gene) 
Low_D_Ovary_Iso_Genes<-unique(Low_D_Ovary_Iso_sorted) ## 1522 genes 
write.table(Low_D_Ovary_Iso_Genes, "Low_D_Ovary_Iso_Genes", quote=F, sep="\n", row.names=F, col.names=F) 

############################################################################################

##Genes that have DE isoforms, but did not come out in DE analysis at gene level 

DE_Head<-scan("DE_Head", what="") ##1094 DE genes based on gene-level analysis 
de_iso_head<-read.table("DE_Head_Isoform", header=T) 
DE_Iso_Head<-unique(sort(de_iso_head$Gene))  ##2608 genes involved

length(intersect(DE_Head, DE_Iso_Head)) ##669 

library(Hmisc) 
a<-DE_Head[DE_Head %nin% DE_Iso_Head]
Iso_ID<-read.table("ID_Conversion", header=T)
table(a %in% Iso_ID$Gene) 
#FALSE  TRUE 
#   10  415 

b<-DE_Iso_Head[DE_Iso_Head %nin% DE_Head] 
Gene_ID<-read.table("~/Desktop/first RNAseq paper/reg_head.matrix", header=T)
table(b %in% Gene_ID$Gene) 
#FALSE  TRUE 
#   12  1927 


###

DE_Ovary<-scan("DE_Ovary", what="") ##1173 DE genes based on gene-level analysis 
de_iso_ovary<-read.table("DE_Ovary_Isoform", header=T) 
DE_Iso_Ovary<-unique(sort(de_iso_ovary$Gene))  ##2491 genes involved

length(intersect(DE_Ovary, DE_Iso_Ovary)) ##850 

library(Hmisc) 
a<-DE_Ovary[DE_Ovary %nin% DE_Iso_Ovary]
Iso_ID<-read.table("ID_Conversion", header=T)
table(a %in% Iso_ID$Gene) 
#FALSE  TRUE 
#   20  1621 

b<-DE_Iso_Ovary[DE_Iso_Ovary %nin% DE_Ovary] 
Gene_ID<-read.table("~/Desktop/first RNAseq paper/reg_ovary.matrix", header=T)
table(b %in% Gene_ID$Gene) 
#FALSE  TRUE 
#   20  1621 

#############################################################################################

##Genes that have antagonistic isoforms 

High_D_Head_Iso_Genes<-scan("High_D_Head_Iso_Genes", what="") 
Low_D_Head_Iso_Genes<-scan("Low_D_Head_Iso_Genes", what="") 

Antag_Head<-intersect(High_D_Head_Iso_Genes, Low_D_Head_Iso_Genes) ##481 genes have both significantly up- and down- regulated isoforms 

write.table(Antag_Head, "Antag_Head", quote=F, sep="\n", row.names=F, col.names=F) 

###

High_D_Ovary_Iso_Genes<-scan("High_D_Ovary_Iso_Genes", what="") 
Low_D_Ovary_Iso_Genes<-scan("Low_D_Ovary_Iso_Genes", what="") 

Antag_Ovary<-intersect(High_D_Ovary_Iso_Genes, Low_D_Ovary_Iso_Genes) ##438 genes have both significantly up- and down- regulated isoforms 

write.table(Antag_Ovary, "Antag_Ovary", quote=F, sep="\n", row.names=F, col.names=F) 

### 

Antag_Head<-scan("Antag_Head", what="") 
Head<-read.table("isoform_Head_result", header=T) 

data<-Head[Head$Gene %in% Antag_Head,] 
sorted_data<-data[order(data$Gene),]
write.table(sorted_data, "Antag_Head_data", quote=F, sep="\t", row.names=F) 


Antag_Ovary<-scan("Antag_Ovary", what="") 
Ovary<-read.table("isoform_Ovary_result", header=T) 

data<-Ovary[Ovary$Gene %in% Antag_Ovary,] 
sorted_data<-data[order(data$Gene),]
write.table(sorted_data, "Antag_Ovary_data", quote=F, sep="\t", row.names=F)







