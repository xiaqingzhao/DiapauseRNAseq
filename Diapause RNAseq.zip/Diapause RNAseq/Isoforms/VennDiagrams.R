library(VennDiagram)

##Head 

draw.pairwise.venn(1094, 2608, 669, category=c("Genes that are DE at gene-level test", "Genes that have at least 1 DE isoform"), ext.text=F, cat.pos=c(10,0), cat.dist=c(0.05, 0.03)) 

##Ovary

draw.pairwise.venn(1173, 2491, 850, category=c("Genes that are DE at gene-level test", "Genes that have at least 1 DE isoform"), ext.text=F, cat.pos=c(15,0), cat.dist=c(0.05, 0.03))