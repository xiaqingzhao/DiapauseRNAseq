library(EBSeq)
data<-read.table(file="reg_head.matrix", row.names=1, header=T) 
GeneMat<-data.matrix(data)

Condition<-as.factor(c("D", "ND"))
Sizes<-MedianNorm(GeneMat)

EBOut<-EBTest(Data=GeneMat, Conditions=Condition, sizeFactors=Sizes, maxround=10)
PP<-GetPPMat(EBOut)
write.table(PP, "reg_head", quote=F, sep="\t") 

GeneFC<-PostFC(EBOut)
write.table(GeneFC, "FC_reg_head", quote=F, sep="\t")



################################################################################

data<-read.table(file="reg_ovary.matrix", row.names=1, header=T) 
GeneMat<-data.matrix(data)

Condition<-as.factor(c("D", "ND"))
Sizes<-MedianNorm(GeneMat)

EBOut<-EBTest(Data=GeneMat, Conditions=Condition, sizeFactors=Sizes, maxround=10)
PP<-GetPPMat(EBOut)
write.table(PP, "reg_ovary", quote=F, sep="\t") 

GeneFC<-PostFC(EBOut)
write.table(GeneFC, "FC_reg_ovary", quote=F, sep="\t")

#Then consolidate reg_head and FC_reg_head into gene_head, and reg_ovary and FC_reg_ovary into gene_ovary




#################################################################################

#Use the transcript name of the *.isoforms.matrix file as list of all transcripts. Convert them to gene identifiers. 

#Clean up isoform data (delete isoforms that cannot be attributed to gene)
List<-read.table("IsosGeneNames", header=T)
good<-complete.cases(List)

HeadIso<-read.table("head.isoforms.matrix", header=T)
headIso<-HeadIso[good,]
write.table(headIso, "reg_head.isoforms.cleaned.matrix", quote=F, sep="\t", row.names=T, col.names=T)

OvaryIso<-read.table("ovary.isoforms.matrix", header=T)
ovaryIso<-OvaryIso[good,]
write.table(ovaryIso, "reg_ovary.isoforms.cleaned.matrix", quote=F, sep="\t", row.names=T, col.names=T)

IsosGeneNames<-List[good, ]
write.table(IsosGeneNames, "IsosGeneNames_cleaned", quote=F, sep="\n", row.names=F, col.names=T)


################################################################################

library(EBSeq)
data<-read.table(file="reg_head.isoforms.cleaned.matrix", header=T, row.names=1) 

IsoMat<-data.matrix(data)

isonames<-read.table(file="reg_head.isoforms.cleaned.matrix", header=T)
IsoNames<-isonames[,1]

isosgenenames<-read.table(file="IsosGeneNames_cleaned", header=T)
IsosGeneNames<-isosgenenames[,1]

IsoSizes<-MedianNorm(IsoMat) 

##D 1.020776   ND 0.979647

NgList<-GetNg(IsoNames, IsosGeneNames)
IsoNgTrun<-NgList$IsoformNgTrun

Condition<-as.factor(c("D", "ND"))

IsoEBOut<-EBTest(Data=IsoMat, NgVector=IsoNgTrun, Conditions=Condition, sizeFactors=IsoSizes, maxround=10)
IsoPP<-GetPPMat(IsoEBOut)
write.table(IsoPP, "reg_head_isoform", quote=F, sep="\t")
IsoFC<-PostFC(IsoEBOut)
write.table(IsoFC, "reg_head_isoform_FC", quote=F, sep="\t")


#######

data<-read.table(file="reg_ovary.isoforms.cleaned.matrix", header=T, row.names=1) 

IsoMat<-data.matrix(data)

isonames<-read.table(file="reg_ovary.isoforms.cleaned.matrix", header=T)
IsoNames<-isonames[,1]

isosgenenames<-read.table(file="IsosGeneNames_cleaned", header=T)
IsosGeneNames<-isosgenenames[,1]

IsoSizes<-MedianNorm(IsoMat)

#NgList<-GetNg(IsoNames, IsosGeneNames)
#IsoNgTrun<-NgList$IsoformNgTrun

Condition<-as.factor(c("D", "ND"))

IsoEBOut<-EBTest(Data=IsoMat, NgVector=IsoNgTrun, Conditions=Condition, sizeFactors=IsoSizes, maxround=10)
IsoPP<-GetPPMat(IsoEBOut)
write.table(IsoPP, "reg_ovary_isoform", quote=F, sep="\t")
IsoFC<-PostFC(IsoEBOut)
write.table(IsoFC, "reg_ovary_isoform_FC", quote=F, sep="\t")





