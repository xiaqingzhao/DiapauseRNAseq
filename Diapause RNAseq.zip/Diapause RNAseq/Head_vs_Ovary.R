Head<-read.table("gene_Head_result", header=T) 
Ovary<-read.table("gene_Ovary_result", header=T) 

DE_Head<-Head[Head$DE==T,] 
DE_Ovary<-Ovary[Ovary$DE==T,] 

length(intersect(DE_Head$Gene, DE_Ovary$Gene)) #165 genes are DE in both head and ovary. 
write.table(intersect(DE_Head$Gene, DE_Ovary$Gene), file="temp", quote=F, sep="\n", row.names=F) 

H_Head<-Head[Head$DE==T & Head$D_head>Head$ND_head,] 
L_Head<-Head[Head$DE==T & Head$D_head<Head$ND_head,] 
H_Ovary<-Ovary[Ovary$DE==T & Ovary$D_ovary>Ovary$ND_ovary,] 
L_Ovary<-Ovary[Ovary$DE==T & Ovary$D_ovary<Ovary$ND_ovary,] 

length(intersect(H_Head$Gene, H_Ovary$Gene)) # 35 geens are High in both head and ovary 
length(intersect(L_Head$Gene, L_Ovary$Gene)) #89 genes are Low in both head and ovary 
length(intersect(H_Head$Gene, L_Ovary$Gene)) #21 genes are high in head and low in ovary 
length(intersect(L_Head$Gene, H_Ovary$Gene)) #20 genes are low in head and high in ovary 

write.table(intersect(H_Head$Gene, H_Ovary$Gene), file="temp", quote=F, sep="\n", row.names=F) 
write.table(intersect(L_Head$Gene, L_Ovary$Gene), file="temp", quote=F, sep="\n", row.names=F) 
write.table(intersect(H_Head$Gene, L_Ovary$Gene), file="temp", quote=F, sep="\n", row.names=F) 
write.table(intersect(L_Head$Gene, H_Ovary$Gene), file="temp", quote=F, sep="\n", row.names=F)