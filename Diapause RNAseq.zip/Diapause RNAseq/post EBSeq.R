##Get rid of the genes that were deleted by EBSeq, and combine the RPKM values with fold change and p values 

Head_RPKM <- read.table("reg_head.matrix", header=T) 
Head_Test <- read.table("gene_head", header=T) 

Exist <- Head_RPKM$Gene %in% Head_Test$Gene

usedHead_RPKM <- Head_RPKM[Exist,] 

write.table(usedHead_RPKM, file="used_head.matrix", quote=F, sep="\t", row.names=F) 

##########

Ovary_RPKM <- read.table("reg_ovary.matrix", header=T) 
Ovary_Test <- read.table("gene_ovary", header=T) 

Exist <- Ovary_RPKM$Gene %in% Ovary_Test$Gene

usedOvary_RPKM <- Ovary_RPKM[Exist,] 

write.table(usedOvary_RPKM, file="used_ovary.matrix", quote=F, sep="\t", row.names=F) 

######################################################################################

##Label genes with DE and not DE
Head <- read.table("gene_Head_result", header=T) 

N<-nrow(Head) 

DE<-rep(NA,N)

for(i in 1:N) {
	if (Head$PPEE[i]<=0.05) {
		DE[i]<-TRUE
	} else {DE[i]<-FALSE}
}

Head<-cbind(Head, DE)

write.table(Head, file="gene_Head_result", quote=F, sep="\t", row.names=F, col.names=T) 

###########

Ovary <- read.table("gene_Ovary_result", header=T) 

N<-nrow(Ovary) 

DE<-rep(NA,N)

for(i in 1:N) {
	if (Ovary$PPEE[i]<=0.05) {
		DE[i]<-TRUE
	} else {DE[i]<-FALSE}
}

Ovary<-cbind(Ovary, DE)

write.table(Ovary, file="gene_Ovary_result", quote=F, sep="\t", row.names=F, col.names=T) 

########################################################################################## 

##Get Normalized RPKM value and log 2 fold change for each gene. Normalizing parameters from EBSeq 
## D_head 1.0270554 ND_head 0.9736573  D_ovary 1.0638939 ND_ovary 0.9399433 

########################################################################################## 

##Get DE genes 

Head <- read.table("gene_Head_result", header=T) 

High_D_Head <- subset(Head, Head$PPEE<=0.05 & Head$D_head>Head$ND_head, select=c(Gene, D_head, ND_head, PPEE, RealFC)) 
Low_D_Head <- subset(Head, Head$PPEE<=0.05 & Head$D_head<Head$ND_head, select=c(Gene, D_head, ND_head, PPEE, RealFC)) 

write.table(High_D_Head, file="High_D_Head", quote=F, sep="\t", row.names=F, col.names=T)
write.table(Low_D_Head, file="Low_D_Head", quote=F, sep="\t", row.names=F, col.names=T) 

####

Ovary <- read.table("gene_Ovary_result", header=T) 

High_D_Ovary <- subset(Ovary, Ovary$PPEE<=0.05 & Ovary$D_ovary>Ovary$ND_ovary, select=c(Gene, D_ovary, ND_ovary, PPEE, RealFC)) 
Low_D_Ovary <- subset(Ovary, Ovary$PPEE<=0.05 & Ovary$D_ovary<Ovary$ND_ovary, select=c(Gene, D_ovary, ND_ovary, PPEE, RealFC)) 

write.table(High_D_Ovary, file="High_D_Ovary", quote=F, sep="\t", row.names=F, col.names=T)
write.table(Low_D_Ovary, file="Low_D_Ovary", quote=F, sep="\t", row.names=F, col.names=T) 

############################################################################################

##Getting background gene lists for GO enrichment  

Head <- read.table("reg_head.matrix", header=T) 

Head_Expressed <- subset(Head, reg_D_head.genes.results>1 | reg_ND_head.genes.results>1, select=Gene) 

write.table(Head_Expressed, file="Head_Expressed", quote=F, sep="\t", row.names=F, col.names=F) 

#####

Ovary <- read.table("reg_ovary.matrix", header=T) 

Ovary_Expressed <- subset(Ovary, reg_D_ovary.genes.results>1 | reg_ND_ovary.genes.results>1, select=Gene) 

write.table(Ovary_Expressed, file="Ovary_Expressed", quote=F, sep="\t", row.names=F, col.names=F) 

############################################################################################

##Combine RPKM values with fold change and p values for isoform data 

Head_Iso_RPKM<-read.table("reg_head.isoforms.cleaned.matrix", header=T) 
Head_Iso_Result<-read.table("isoform_head", header=T) 

a<-merge(Head_Iso_RPKM, Head_Iso_Result, by="Transcript")

write.table(a, "isoform_Head_result", quote=F, sep="\t", row.names=F) 

########

Ovary_Iso_RPKM<-read.table("reg_ovary.isoforms.cleaned.matrix", header=T) 
Ovary_Iso_Result<-read.table("isoform_ovary", header=T) 

b<-merge(Ovary_Iso_RPKM, Ovary_Iso_Result, by="Transcript")

write.table(b, "isoform_Ovary_result", quote=F, sep="\t", row.names=F) 



