OddsRatio <- function(mymatrix) {
	oddsRatio<-I(mymatrix[1,1]/mymatrix[2,1])/I(mymatrix[1,2]/mymatrix[2,2]) 
	
	se<-sqrt(1/mymatrix[1,1]+1/mymatrix[2,1]+1/mymatrix[1,2]+1/mymatrix[2,2]) 
	
	CILow<-exp(log(oddsRatio)-1.96*se)
	
	CIHigh<-exp(log(oddsRatio)+1.96*se)
	
	CI<-c(CILow, CIHigh)
	
	print(oddsRatio) 
	print(CI) 
} 

#########################################################################################

Head_DE<-read.table("HeadMatch_DE_treated.txt", header=T) 
Head_EE<-read.table("HeadMatch_DE_control.txt", header=T) 

sum(Head_DE$Seasonal) #153 
length(Head_DE$Gene) #1088 

sum(Head_EE$Seasonal) #130
length(Head_EE$Gene) #1088 

Head_Sea_matrix<-matrix(c(sum(Head_DE$Seasonal), sum(Head_EE$Seasonal), I(length(Head_DE$Gene)-sum(Head_DE$Seasonal)), I(length(Head_EE$Gene)-sum(Head_EE$Seasonal))), nrow=2, dimnames=list("DE/EE"=c("DE", "EE"), "Seasonal"=c("Yes", "No"))) 

fisher.test(Head_Sea_matrix) 

calcOddsRatio(Head_matrix) 

###

Clinal<-scan("Clinal", what="") 

a<-length(intersect(Head_DE$Gene, Clinal)) #645 
t1<-length(Head_DE$Gene) #443 

b<-length(intersect(Head_EE$Gene, Clinal)) #645 
t2<-length(Head_EE$Gene) 

Head_Cli_matrix<-matrix(c(a,b,(t1-a),(t2-b)), nrow=2, dimnames=list("DE/EE"=c("DE", "EE"), "Clinal"=c("Yes", "No")))



##############################################################################
Ovary_DE<-read.table("OvaryMatch_DE_treated.txt", header=T) 
Ovary_EE<-read.table("OvaryMatch_DE_control.txt", header=T) 

sum(Ovary_DE$Seasonal) #162 
length(Ovary_DE$Gene) #1167 

sum(Ovary_EE$Seasonal) #176 
length(Ovary_EE$Gene) #1167  

Ovary_Sea_matrix<-matrix(c(sum(Ovary_DE$Seasonal), sum(Ovary_EE$Seasonal), I(length(Ovary_DE$Gene)-sum(Ovary_DE$Seasonal)), I(length(Ovary_EE$Gene)-sum(Ovary_EE$Seasonal))), nrow=2, dimnames=list("DE/EE"=c("DE", "EE"), "Seasonal"=c("Yes", "No"))) 


a<-length(intersect(Ovary_DE$Gene, Clinal)) #674 
t1<-length(Ovary_DE$Gene) #493  

b<-length(intersect(Ovary_EE$Gene, Clinal)) #645 
t2<-length(Ovary_EE$Gene) 

Ovary_Cli_matrix<-matrix(c(a,b,(t1-a),(t2-b)), nrow=2, dimnames=list("DE/EE"=c("DE", "EE"), "Clinal"=c("Yes", "No"))) 

###############################################################################################

FM<-scan("FM.txt", what="") 

FM<-as.factor(FM) 

length(intersect(FM, Head_DE$Gene)) #135
length(intersect(FM, Head_EE$Gene)) #103 

length(intersect(FM, Ovary_DE$Gene)) #156
length(intersect(FM, Ovary_EE$Gene)) #147 

### 

PM<-scan("PM.txt", what="") 

PM<-as.factor(PM) 

length(intersect(PM, Head_DE$Gene)) #41
length(intersect(PM, Head_EE$Gene)) #33 

length(intersect(PM, Ovary_DE$Gene)) #65
length(intersect(PM, Ovary_EE$Gene)) #57 

### 

FP<-scan("FP.txt", what="") 

FP<-as.factor(FP) 

length(intersect(FP, Head_DE$Gene)) #122
length(intersect(FP, Head_EE$Gene)) #121 

length(intersect(FP, Ovary_DE$Gene)) #163
length(intersect(FP, Ovary_EE$Gene)) #142 







