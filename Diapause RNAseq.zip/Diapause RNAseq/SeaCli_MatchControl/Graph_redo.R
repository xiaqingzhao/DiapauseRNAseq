#Re-do Figure 2

##Multiplot function 

multiplot <- function(..., plotlist=NULL, file, cols=1, layout=NULL) {
  require(grid)

  # Make a list from the ... arguments and plotlist
  plots <- c(list(...), plotlist)

  numPlots = length(plots)

  # If layout is NULL, then use 'cols' to determine layout
  if (is.null(layout)) {
    # Make the panel
    # ncol: Number of columns of plots
    # nrow: Number of rows needed, calculated from # of cols
    layout <- matrix(seq(1, cols * ceiling(numPlots/cols)),
                    ncol = cols, nrow = ceiling(numPlots/cols))
  }

 if (numPlots==1) {
    print(plots[[1]])

  } else {
    # Set up the page
    grid.newpage()
    pushViewport(viewport(layout = grid.layout(nrow(layout), ncol(layout))))

    # Make each plot, in the correct location
    for (i in 1:numPlots) {
      # Get the i,j matrix positions of the regions that contain this subplot
      matchidx <- as.data.frame(which(layout == i, arr.ind = TRUE))

      print(plots[[i]], vp = viewport(layout.pos.row = matchidx$row,
                                      layout.pos.col = matchidx$col))
    }
  }
}


######## 

library(ggplot2)

DE_Sea<-read.table("DE_Seasonal.txt", header=T)

p1<-ggplot(DE_Sea, aes(x=DE_Sea$EE_Seasonal))+geom_histogram(binwidth=5, colour="black", fill="white")+geom_vline(aes(xintercept=DE_Sea$DE_Seasonal), colour="red")+facet_grid(.~Tissue, scales="free")+theme(axis.title.x=element_blank()) 

p2<-ggplot(DE_Sea, aes(x=DE_Sea$Tissue, y=DE_Sea$p))+geom_boxplot()+geom_hline(aes(yintercept=0.05), colour="red", linetype="dashed")+ylim(0,1)+ylab("p value of Fisher's exact test")+theme(axis.title.x=element_blank()) 

multiplot(p1,p2,cols=1) 

###

DE_Cli<-read.table("DE_Clinal.txt", header=T) 

p3<-ggplot(DE_Cli, aes(x=DE_Cli$EE_Clinal))+geom_histogram(binwidth=5, colour="black", fill="white")+geom_vline(aes(xintercept=DE_Cli$DE_Clinal), colour="red")+facet_grid(.~Tissue, scales="free")+theme(axis.title.x=element_blank()) 

p4<-ggplot(DE_Cli, aes(x=DE_Cli$Tissue, y=DE_Cli$p))+geom_boxplot()+geom_hline(aes(yintercept=0.05), colour="red", linetype="dashed")+ylim(0,1)+ylab("p value of Fisher's exact test")+theme(axis.title.x=element_blank()) 

multiplot(p3,p4,cols=1) 

########  

##Re-do Figure 3 

HL_Sea<-read.table("HL_Seasonal.txt", header=T)

p1<-ggplot(HL_Sea, aes(x=HL_Sea$Control))+geom_histogram(binwidth=5, colour="black", fill="white")+geom_vline(aes(xintercept=HL_Sea$Target), colour="red")+facet_grid(.~Group)+theme(axis.title.x=element_blank())+labs(title="(a)")+theme(plot.title=element_text(hjust=0))


p2<-ggplot(HL_Sea, aes(x=HL_Sea$Group, y=HL_Sea$p))+geom_boxplot()+geom_hline(aes(yintercept=0.05), colour="red", linetype="dashed")+ylim(0,1)+ylab("p value of Fisher's exact test")+theme(axis.title.x=element_blank())+labs(title="(b)")+theme(plot.title=element_text(hjust=0))

multiplot(p1,p2,cols=1) 

### 

HL_Cli<-read.table("HL_Clinal.txt", header=T)

p1<-ggplot(HL_Cli, aes(x=HL_Cli$Control))+geom_histogram(binwidth=5, colour="black", fill="white")+geom_vline(aes(xintercept=HL_Cli$Target), colour="red")+facet_grid(.~Group)+theme(axis.title.x=element_blank())+labs(title="(a)")+theme(plot.title=element_text(hjust=0)) 

p2<-ggplot(HL_Cli, aes(x=HL_Cli$Group, y=HL_Cli$p))+geom_boxplot()+geom_hline(aes(yintercept=0.05), colour="red", linetype="dashed")+ylim(0,1)+ylab("p value of Fisher's exact test")+theme(axis.title.x=element_blank())+labs(title="(b)")+theme(plot.title=element_text(hjust=0)) 

multiplot(p1,p2,cols=1)



