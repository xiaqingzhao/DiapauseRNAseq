Head<-read.table("Head.txt", header=T) 

Loc<-read.table("Loc.txt", header=T, sep="\t") 

GeneLoc<-Loc[match(Head$Gene, Loc$Gene),] 

write.table(cbind(Head, GeneLoc), "Head_Loc", quote=F, sep="\t", row.names=F) 

#######
Head<-read.table("Head_Loc.txt", header=T, sep="\t") 
Sea<-scan("Seasonal", what="") 

Seasonal<-rep(NA, length(Head$Gene)) 

for (i in 1:length(Head$Gene)) {
	Seasonal[i]<-Head$Gene[i] %in% factor(Sea) 
} 

write.table(Seasonal, "Head_Seasonal", quote=F, sep="\n", row.names=F)

########

Ovary<-read.table("Ovary.txt", header=T) 

Loc<-read.table("Loc.txt", header=T, sep="\t") 

GeneLoc<-Loc[match(Ovary$Gene, Loc$Gene),] 

write.table(cbind(Ovary, GeneLoc), "Ovary_Loc", quote=F, sep="\t", row.names=F) 

#########

Ovary<-read.table("Ovary_Loc.txt", header=T, sep="\t") 
Sea<-scan("Seasonal", what="") 

Seasonal<-rep(NA, length(Ovary$Gene)) 

for (i in 1:length(Ovary$Gene)) {
	Seasonal[i]<-Ovary$Gene[i] %in% factor(Sea) 
} 

write.table(Seasonal, "Ovary_Seasonal", quote=F, sep="\n", row.names=F)



 