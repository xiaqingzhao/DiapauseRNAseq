# data<-read.table("Head_Loc.txt", header=T, sep="\t")

# length<-data$End-data$Start
# data<-data.frame(data, length) 

# write.table(data, "Head_Match.txt", quote=F, sep="\t", row.names=F) 

##

# data<-read.table("Ovary_Loc.txt", header=T, sep="\t")

# length<-data$End-data$Start
# data<-data.frame(data, length) 

# write.table(data, "Ovary_Match.txt", quote=F, sep="\t", row.names=F) 

###

##Genetic matching 

library("Matching")

data<-read.table("Head_Match.txt", header=T, sep="\t")

index<-!is.na(data$length)
data<-data[index, ]

X<-cbind(data$mean_RPKM, data$length) 

BalanceMatrix<-cbind(data$mean_RPKM, data$length, I(data$mean_RPKM^2), I(data$length^2), I(data$mean_RPKM*data$length)) 

gen<-GenMatch(Tr=data$DE, X=X, BalanceMatrix=BalanceMatrix, pop.size=1000, ties=F) 

mgen<-Match(Y=data$Seasonal, Tr=data$DE, X=X, Weight.matrix=gen) 

summary(mgen) 

MatchBalance(DE~mean_RPKM+length+I(mean_RPKM*length), match.out=mgen, nboots=1000, data=data) 

DE_treat<-data[gen$matches[,1],] 

write.table(DE_treat, "HeadMatch_DE_treated", quote=F, sep="\t", row.names=F) 

DE_control<-data[gen$matches[,2],] 

write.table(DE_control, "HeadMatch_DE_control", quote=F, sep="\t", row.names=F) 


#####


library("Matching")

data<-read.table("Ovary_Match.txt", header=T, sep="\t")

index<-!is.na(data$length)
data<-data[index, ]

X<-cbind(data$mean_RPKM, data$length) 

BalanceMatrix<-cbind(data$mean_RPKM, data$length, I(data$mean_RPKM^2), I(data$length^2), I(data$mean_RPKM*data$length)) 

gen<-GenMatch(Tr=data$DE, X=X, BalanceMatrix=BalanceMatrix, pop.size=1000, ties=F) 

mgen<-Match(Y=data$Seasonal, Tr=data$DE, X=X, Weight.matrix=gen) 

summary(mgen) 

MatchBalance(DE~mean_RPKM+length+I(mean_RPKM*length), match.out=mgen, nboots=1000, data=data) 

DE_treat<-data[gen$matches[,1],] 

write.table(DE_treat, "OvaryMatch_DE_treated", quote=F, sep="\t", row.names=F) 

DE_control<-data[gen$matches[,2],] 

write.table(DE_control, "OvaryMatch_DE_control", quote=F, sep="\t", row.names=F) 

###################### 

##Bootstrap 

library("Matching")

data<-read.table("Head_Match.txt", header=T, sep="\t")

index<-!is.na(data$length)
data<-data[index, ]

X<-cbind(data$mean_RPKM, data$length) 

BalanceMatrix<-cbind(data$mean_RPKM, data$length, I(data$mean_RPKM^2), I(data$length^2), I(data$mean_RPKM*data$length)) 

GenMatches<-list() 

n=10 

for (i in 1:n) {
  gen<-GenMatch(Tr=data$DE, X=X, BalanceMatrix=BalanceMatrix, pop.size=500, ties=F) 
  mgen<-Match(Y=data$Seasonal, Tr=data$DE, X=X, Weight.matrix=gen) 
  print(summary(mgen)) 
  GenMatches[[i]]<-gen$matches 
} 

Head_20bootstraps<-GenMatches
save(GenMatches, file="Head_20bootstraps.RData") 

##### 

library("Matching")

data<-read.table("Ovary_Match.txt", header=T, sep="\t")

index<-!is.na(data$length)
data<-data[index, ]

X<-cbind(data$mean_RPKM, data$length) 

BalanceMatrix<-cbind(data$mean_RPKM, data$length, I(data$mean_RPKM^2), I(data$length^2), I(data$mean_RPKM*data$length)) 

GenMatches<-list() 

n=20 

for (i in 1:n) {
  gen<-GenMatch(Tr=data$DE, X=X, BalanceMatrix=BalanceMatrix, pop.size=500, ties=F) 
  mgen<-Match(Y=data$Seasonal, Tr=data$DE, X=X, Weight.matrix=gen) 
  print(summary(mgen)) 
  GenMatches[[i]]<-gen$matches 
} 

Ovary_20bootstraps<-GenMatches
save(GenMatches, file="Ovary_10bootstraps.RData") 






# library("Matching") 

# data<-read.table("Head_Match.txt", header=T, sep="\t")

# index<-!is.na(data$length)
# data<-data[index, ] 

# glm1<-glm(DE~mean_RPKM+length, family=binomial(), data=data)

# result<-Match(Y=data$Seasonal, Tr=data$DE, X=glm1$fitted, tie=T) 

# summary(result) 

# MatchBalance(DE~mean_RPKM+length+I(mean_RPKM*length), match.out=result, nboots=1000, data=data) 

###

# glm2<-glm(DE~mean_RPKM+mean_RPKM^2+length+length^2+mean_RPKM*length, family=binomial(), data=data)

# result<-Match(Y=data$Seasonal, Tr=data$DE, X=glm2$fitted) 

# summary(result) 

# MatchBalance(DE~mean_RPKM+length+I(mean_RPKM*length), match.out=result, nboots=1000, data=data) 


### 

 



######

# library("Matching") 

# data<-read.table("Ovary_Match.txt", header=T, sep="\t")

# index<-!is.na(data$length)
# data<-data[index, ] 

# glm1<-glm(DE~mean_RPKM+length, family=binomial(), data=data)

# result<-Match(Y=data$Seasonal, Tr=data$DE, X=glm1$fitted, tie=T) 

# summary(result) 

# MatchBalance(DE~mean_RPKM+length+I(mean_RPKM*length), match.out=result, nboots=1000, data=data) 

###

# # glm2<-glm(DE~mean_RPKM+mean_RPKM^2+length+length^2+mean_RPKM*length, family=binomial(), data=data)

# result<-Match(Y=data$Seasonal, Tr=data$DE, X=glm2$fitted) 

# summary(result) 

# MatchBalance(DE~mean_RPKM+length+I(mean_RPKM*length), match.out=result, nboots=1000, data=data) 


### 




