##Open .RData files by double-clicking. 

Head_bs<-Head_bs_100 

data<-read.table("Head_Match.txt", header=T, sep="\t") 

index<-!is.na(data$length)
data<-data[index, ] 

n<-length(Head_bs) #Number of bootstraps 


OddsRatio<-rep(NA, n) 
p<-rep(NA, n) 
LowCI<-rep(NA, n) 
HighCI<-rep(NA, n) 
High_Seasonal<-rep(NA, n) 
High_Control_Seasonal<-rep(NA, n) 


for (i in 1:n) {
	
	DE<-data[Head_bs[[i]][,1],] 
	EE<-data[Head_bs[[i]][,2],] 
	
	High<-DE[which(DE$D_head_norm>DE$ND_head_norm),] 
	High_Control<-EE[which(DE$D_head_norm>DE$ND_head_norm),] 
	
	Sea_matrix<-matrix(c(sum(High$Seasonal), sum(High_Control$Seasonal), I(length(High$Gene)-sum(High$Seasonal)), I(length(High_Control$Gene)-sum(High_Control$Seasonal))), nrow=2, dimnames=list("DE/EE"=c("DE", "EE"), "Seasonal"=c("Yes", "No"))) 
	
	fisher<-fisher.test(Sea_matrix) 
	
	High_Seasonal[i]<-sum(High$Seasonal)
	High_Control_Seasonal[i]<-sum(High_Control$Seasonal)
	OddsRatio[i]<-fisher$estimate 
	p[i]<-fisher$p.value 
	LowCI[i]<-fisher$conf.int[1] 
	HighCI[i]<-fisher$conf.int[2] 
	
}

result<-cbind(High_Seasonal, High_Control_Seasonal, OddsRatio, p, LowCI, HighCI) 
write.table(result, "Head_High_Seasonal_output.txt", quote=F, sep="\t", row.names=F) 

## 

Head_bs<-Head_bs_100 

data<-read.table("Head_Match.txt", header=T, sep="\t") 

index<-!is.na(data$length)
data<-data[index, ] 

n<-length(Head_bs) #Number of bootstraps 


OddsRatio<-rep(NA, n) 
p<-rep(NA, n) 
LowCI<-rep(NA, n) 
HighCI<-rep(NA, n) 
Low_Seasonal<-rep(NA, n) 
Low_Control_Seasonal<-rep(NA, n) 


for (i in 1:n) {
	
	DE<-data[Head_bs[[i]][,1],] 
	EE<-data[Head_bs[[i]][,2],] 
	
	Low<-DE[which(DE$D_head_norm<DE$ND_head_norm),] 
	Low_Control<-EE[which(DE$D_head_norm<DE$ND_head_norm),] 
	
	Sea_matrix<-matrix(c(sum(Low$Seasonal), sum(Low_Control$Seasonal), I(length(Low$Gene)-sum(Low$Seasonal)), I(length(Low_Control$Gene)-sum(Low_Control$Seasonal))), nrow=2, dimnames=list("DE/EE"=c("DE", "EE"), "Seasonal"=c("Yes", "No"))) 
	
	fisher<-fisher.test(Sea_matrix) 
	
	Low_Seasonal[i]<-sum(Low$Seasonal)
	Low_Control_Seasonal[i]<-sum(Low_Control$Seasonal)
	OddsRatio[i]<-fisher$estimate 
	p[i]<-fisher$p.value 
	LowCI[i]<-fisher$conf.int[1] 
	HighCI[i]<-fisher$conf.int[2] 
	
}

result<-cbind(Low_Seasonal, Low_Control_Seasonal, OddsRatio, p, LowCI, HighCI) 
write.table(result, "Head_Low_Seasonal_output.txt", quote=F, sep="\t", row.names=F) 


############################ 

Head_bs<-Head_bs_100 

data<-read.table("Head_Match.txt", header=T, sep="\t") 

index<-!is.na(data$length)
data<-data[index, ] 

n<-length(Head_bs) #Number of bootstraps 


OddsRatio<-rep(NA, n) 
p<-rep(NA, n) 
LowCI<-rep(NA, n) 
HighCI<-rep(NA, n) 
High_Clinal<-rep(NA, n) 
High_Control_Clinal<-rep(NA, n) 


for (i in 1:n) {
	
	DE<-data[Head_bs[[i]][,1],] 
	EE<-data[Head_bs[[i]][,2],] 
	
	High<-DE[which(DE$D_head_norm>DE$ND_head_norm),] 
	High_Control<-EE[which(DE$D_head_norm>DE$ND_head_norm),] 
	
	Cli_matrix<-matrix(c(sum(High$Clinal), sum(High_Control$Clinal), I(length(High$Gene)-sum(High$Clinal)), I(length(High_Control$Gene)-sum(High_Control$Clinal))), nrow=2, dimnames=list("DE/EE"=c("DE", "EE"), "Clinal"=c("Yes", "No"))) 
	
	fisher<-fisher.test(Cli_matrix) 
	
	High_Clinal[i]<-sum(High$Clinal)
	High_Control_Clinal[i]<-sum(High_Control$Clinal)
	OddsRatio[i]<-fisher$estimate 
	p[i]<-fisher$p.value 
	LowCI[i]<-fisher$conf.int[1] 
	HighCI[i]<-fisher$conf.int[2] 
	
}

result<-cbind(High_Clinal, High_Control_Clinal, OddsRatio, p, LowCI, HighCI) 
write.table(result, "Head_High_Clinal_output.txt", quote=F, sep="\t", row.names=F)  

### 

Head_bs<-Head_bs_100 

data<-read.table("Head_Match.txt", header=T, sep="\t") 

index<-!is.na(data$length)
data<-data[index, ] 

n<-length(Head_bs) #Number of bootstraps 


OddsRatio<-rep(NA, n) 
p<-rep(NA, n) 
LowCI<-rep(NA, n) 
HighCI<-rep(NA, n) 
Low_Clinal<-rep(NA, n) 
Low_Control_Clinal<-rep(NA, n) 


for (i in 1:n) {
	
	DE<-data[Head_bs[[i]][,1],] 
	EE<-data[Head_bs[[i]][,2],] 
	
	Low<-DE[which(DE$D_head_norm<DE$ND_head_norm),] 
	Low_Control<-EE[which(DE$D_head_norm<DE$ND_head_norm),] 
	
	Cli_matrix<-matrix(c(sum(Low$Clinal), sum(Low_Control$Clinal), I(length(Low$Gene)-sum(Low$Clinal)), I(length(Low_Control$Gene)-sum(Low_Control$Clinal))), nrow=2, dimnames=list("DE/EE"=c("DE", "EE"), "Clinal"=c("Yes", "No"))) 
	
	fisher<-fisher.test(Cli_matrix) 
	
	Low_Clinal[i]<-sum(Low$Clinal)
	Low_Control_Clinal[i]<-sum(Low_Control$Clinal)
	OddsRatio[i]<-fisher$estimate 
	p[i]<-fisher$p.value 
	LowCI[i]<-fisher$conf.int[1] 
	HighCI[i]<-fisher$conf.int[2] 
	
}

result<-cbind(Low_Clinal, Low_Control_Clinal, OddsRatio, p, LowCI, HighCI) 
write.table(result, "Head_Low_Clinal_output.txt", quote=F, sep="\t", row.names=F)  

############## 

##Open .RData files by double-clicking. 

Ovary_bs<-Ovary_bs_100 

data<-read.table("Ovary_Match.txt", header=T, sep="\t") 

index<-!is.na(data$length)
data<-data[index, ] 

n<-length(Ovary_bs) #Number of bootstraps 


OddsRatio<-rep(NA, n) 
p<-rep(NA, n) 
LowCI<-rep(NA, n) 
HighCI<-rep(NA, n) 
High_Seasonal<-rep(NA, n) 
High_Control_Seasonal<-rep(NA, n) 


for (i in 1:n) {
	
	DE<-data[Ovary_bs[[i]][,1],] 
	EE<-data[Ovary_bs[[i]][,2],] 
	
	High<-DE[which(DE$D_ovary_norm>DE$ND_ovary_norm),] 
	High_Control<-EE[which(DE$D_ovary_norm>DE$ND_ovary_norm),] 
	
	Sea_matrix<-matrix(c(sum(High$Seasonal), sum(High_Control$Seasonal), I(length(High$Gene)-sum(High$Seasonal)), I(length(High_Control$Gene)-sum(High_Control$Seasonal))), nrow=2, dimnames=list("DE/EE"=c("DE", "EE"), "Seasonal"=c("Yes", "No"))) 
	
	fisher<-fisher.test(Sea_matrix) 
	
	High_Seasonal[i]<-sum(High$Seasonal)
	High_Control_Seasonal[i]<-sum(High_Control$Seasonal)
	OddsRatio[i]<-fisher$estimate 
	p[i]<-fisher$p.value 
	LowCI[i]<-fisher$conf.int[1] 
	HighCI[i]<-fisher$conf.int[2] 
	
}

result<-cbind(High_Seasonal, High_Control_Seasonal, OddsRatio, p, LowCI, HighCI) 
write.table(result, "Ovary_High_Seasonal_output.txt", quote=F, sep="\t", row.names=F) 

## 

Ovary_bs<-Ovary_bs_100 

data<-read.table("Ovary_Match.txt", header=T, sep="\t") 

index<-!is.na(data$length)
data<-data[index, ] 

n<-length(Ovary_bs) #Number of bootstraps 


OddsRatio<-rep(NA, n) 
p<-rep(NA, n) 
LowCI<-rep(NA, n) 
HighCI<-rep(NA, n) 
Low_Seasonal<-rep(NA, n) 
Low_Control_Seasonal<-rep(NA, n) 


for (i in 1:n) {
	
	DE<-data[Ovary_bs[[i]][,1],] 
	EE<-data[Ovary_bs[[i]][,2],] 
	
	Low<-DE[which(DE$D_ovary_norm<DE$ND_ovary_norm),] 
	Low_Control<-EE[which(DE$D_ovary_norm<DE$ND_ovary_norm),] 
	
	Sea_matrix<-matrix(c(sum(Low$Seasonal), sum(Low_Control$Seasonal), I(length(Low$Gene)-sum(Low$Seasonal)), I(length(Low_Control$Gene)-sum(Low_Control$Seasonal))), nrow=2, dimnames=list("DE/EE"=c("DE", "EE"), "Seasonal"=c("Yes", "No"))) 
	
	fisher<-fisher.test(Sea_matrix) 
	
	Low_Seasonal[i]<-sum(Low$Seasonal)
	Low_Control_Seasonal[i]<-sum(Low_Control$Seasonal)
	OddsRatio[i]<-fisher$estimate 
	p[i]<-fisher$p.value 
	LowCI[i]<-fisher$conf.int[1] 
	HighCI[i]<-fisher$conf.int[2] 
	
}

result<-cbind(Low_Seasonal, Low_Control_Seasonal, OddsRatio, p, LowCI, HighCI) 
write.table(result, "Ovary_Low_Seasonal_output.txt", quote=F, sep="\t", row.names=F) 


############################ 

Ovary_bs<-Ovary_bs_100 

data<-read.table("Ovary_Match.txt", header=T, sep="\t") 

index<-!is.na(data$length)
data<-data[index, ] 

n<-length(Ovary_bs) #Number of bootstraps 


OddsRatio<-rep(NA, n) 
p<-rep(NA, n) 
LowCI<-rep(NA, n) 
HighCI<-rep(NA, n) 
High_Clinal<-rep(NA, n) 
High_Control_Clinal<-rep(NA, n) 


for (i in 1:n) {
	
	DE<-data[Ovary_bs[[i]][,1],] 
	EE<-data[Ovary_bs[[i]][,2],] 
	
	High<-DE[which(DE$D_ovary_norm>DE$ND_ovary_norm),] 
	High_Control<-EE[which(DE$D_ovary_norm>DE$ND_ovary_norm),] 
	
	Cli_matrix<-matrix(c(sum(High$Clinal), sum(High_Control$Clinal), I(length(High$Gene)-sum(High$Clinal)), I(length(High_Control$Gene)-sum(High_Control$Clinal))), nrow=2, dimnames=list("DE/EE"=c("DE", "EE"), "Clinal"=c("Yes", "No"))) 
	
	fisher<-fisher.test(Cli_matrix) 
	
	High_Clinal[i]<-sum(High$Clinal)
	High_Control_Clinal[i]<-sum(High_Control$Clinal)
	OddsRatio[i]<-fisher$estimate 
	p[i]<-fisher$p.value 
	LowCI[i]<-fisher$conf.int[1] 
	HighCI[i]<-fisher$conf.int[2] 
	
}

result<-cbind(High_Clinal, High_Control_Clinal, OddsRatio, p, LowCI, HighCI) 
write.table(result, "Ovary_High_Clinal_output.txt", quote=F, sep="\t", row.names=F)  

### 

Ovary_bs<-Ovary_bs_100 

data<-read.table("Ovary_Match.txt", header=T, sep="\t") 

index<-!is.na(data$length)
data<-data[index, ] 

n<-length(Ovary_bs) #Number of bootstraps 


OddsRatio<-rep(NA, n) 
p<-rep(NA, n) 
LowCI<-rep(NA, n) 
HighCI<-rep(NA, n) 
Low_Clinal<-rep(NA, n) 
Low_Control_Clinal<-rep(NA, n) 


for (i in 1:n) {
	
	DE<-data[Ovary_bs[[i]][,1],] 
	EE<-data[Ovary_bs[[i]][,2],] 
	
	Low<-DE[which(DE$D_ovary_norm<DE$ND_ovary_norm),] 
	Low_Control<-EE[which(DE$D_ovary_norm<DE$ND_ovary_norm),] 
	
	Cli_matrix<-matrix(c(sum(Low$Clinal), sum(Low_Control$Clinal), I(length(Low$Gene)-sum(Low$Clinal)), I(length(Low_Control$Gene)-sum(Low_Control$Clinal))), nrow=2, dimnames=list("DE/EE"=c("DE", "EE"), "Clinal"=c("Yes", "No"))) 
	
	fisher<-fisher.test(Cli_matrix) 
	
	Low_Clinal[i]<-sum(Low$Clinal)
	Low_Control_Clinal[i]<-sum(Low_Control$Clinal)
	OddsRatio[i]<-fisher$estimate 
	p[i]<-fisher$p.value 
	LowCI[i]<-fisher$conf.int[1] 
	HighCI[i]<-fisher$conf.int[2] 
	
}

result<-cbind(Low_Clinal, Low_Control_Clinal, OddsRatio, p, LowCI, HighCI) 
write.table(result, "Ovary_Low_Clinal_output.txt", quote=F, sep="\t", row.names=F)  

############## 





