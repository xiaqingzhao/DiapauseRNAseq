par(mfrow=c(2,2)) 
par(mar=c(2,3,1,3)) 
par(oma=c(1,1,1,1))
par(mgp=c(2,1,0)) 

DE_Sea<-read.table("DE_Sea_graph.txt", header=T) 
DE_Cli<-read.table("DE_Cli_graph.txt", header=T) 

boxplot(DE_Sea$OddsRatio~DE_Sea$Tissue, ylim=c(0.8,1.4), xlab="Tissue", ylab="Odds Ratio", main="Seasonal Enrichment") 
abline(a=1, b=0, col="red")

boxplot(DE_Cli$OddsRatio~DE_Cli$Tissue, ylim=c(0.8,1.4), xlab="Tissue", ylab="Odds Ratio", main="Clinal Enrichment") 
abline(a=1, b=0, col="red")

boxplot(DE_Sea$p~DE_Sea$Tissue, ylim=c(0,0.5), xlab="Tissue", ylab="p value") 
abline(a=0.05, b=0, col="red") 

boxplot(DE_Cli$p~DE_Cli$Tissue, ylim=c(0,0.5), xlab="Tissue", ylab="p value")
abline(a=0.05, b=0, col="red")  

### 
par(mfrow=c(2,2)) 
par(mar=c(1,3,1,3)) 
par(oma=c(1,1,1,1))
par(mgp=c(2,1,0)) 

DE_Sea<-read.table("DE_Sea_graph.txt", header=T) 
DE_Cli<-read.table("DE_Cli_graph.txt", header=T) 

boxplot(DE_Sea$OddsRatio~DE_Sea$Tissue, ylim=c(0.8,1.4), xaxt="n", ylab="Odds Ratio", main="Seasonal Enrichment") 
abline(a=1, b=0, col="red")

boxplot(DE_Cli$OddsRatio~DE_Cli$Tissue, ylim=c(0.8,1.4), xaxt="n", ylab="Odds Ratio", main="Clinal Enrichment") 
abline(a=1, b=0, col="red")

boxplot(DE_Sea$p~DE_Sea$Tissue, ylim=c(0,0.5), xlab="Tissue", ylab="p value") 
abline(a=0.05, b=0, col="red") 

boxplot(DE_Cli$p~DE_Cli$Tissue, ylim=c(0,0.5), xlab="Tissue", ylab="p value")
abline(a=0.05, b=0, col="red") 


##### 

par(mfrow=c(2,2)) 
par(mar=c(1,3,1,3)) 
par(oma=c(1,1,1,1))
par(mgp=c(2,1,0)) 

HL_Sea<-read.table("HL_Seasonal_output.txt", header=T) 
HL_Cli<-read.table("HL_Clinal_output.txt", header=T) 

boxplot(HL_Sea$OddsRatio~HL_Sea$Category, ylim=c(0.2,2.0), xaxt="n", ylab="Odds Ratio", main="Seasonal Enrichment") 
abline(a=1, b=0, col="red")

boxplot(HL_Cli$OddsRatio~HL_Cli$Category, ylim=c(0.2,2.0), xaxt="n", ylab="Odds Ratio", main="Clinal Enrichment") 
abline(a=1, b=0, col="red")

boxplot(HL_Sea$p~HL_Sea$Category, ylim=c(0,1), xaxt="n", ylab="p value") 
axis(side=1,at=c(1,2,3,4), labels=c("Head\nHigh in D", "Head\nLow in D", "Ovary\nHigh in D", "Ovary\nLow in D"), cex.axis=0.75)
abline(a=0.05, b=0, col="red") 

boxplot(HL_Cli$p~HL_Cli$Category, ylim=c(0,1), xaxt="n", ylab="p value") 
axis(side=1,at=c(1,2,3,4), labels=c("Head\nHigh in D", "Head\nLow in D", "Ovary\nHigh in D", "Ovary\nLow in D"), cex.axis=0.75)
abline(a=0.05, b=0, col="red") 





