##Open .RData files by double-clicking. 

Head_bs<-Head_20bootstrap 

data<-read.table("Head_Match.txt", header=T, sep="\t")

index<-!is.na(data$length)
data<-data[index, ] 

n<-length(Head_bs) #Number of bootstraps 


OddsRatio<-rep(NA, n) 
p<-rep(NA, n) 
LowCI<-rep(NA, n) 
HighCI<-rep(NA, n) 
DE_Seasonal<-rep(NA, n) 
EE_Seasonal<-rep(NA, n) 



for (i in 1:n) {
	
	DE<-data[Head_bs[[i]][,1],]
	EE<-data[Head_bs[[i]][,2],] 
	
	Sea_matrix<-matrix(c(sum(DE$Seasonal), sum(EE$Seasonal), I(length(DE$Gene)-sum(DE$Seasonal)), I(length(EE$Gene)-sum(EE$Seasonal))), nrow=2, dimnames=list("DE/EE"=c("DE", "EE"), "Seasonal"=c("Yes", "No"))) 
	
	fisher<-fisher.test(Sea_matrix) 
	
	DE_Seasonal[i]<-sum(DE$Seasonal) 
	EE_Seasonal[i]<-sum(EE$Seasonal) 
	OddsRatio[i]<-fisher$estimate 
	p[i]<-fisher$p.value 
	LowCI[i]<-fisher$conf.int[1] 
	HighCI[i]<-fisher$conf.int[2] 
	
} 

result<-cbind(DE_Seasonal, EE_Seasonal, OddsRatio, p, LowCI, HighCI) 
write.table(result, "Head_DE_Seasonal_output.txt", quote=F, sep="\t", row.names=F) 


#### 

Ovary_bs<-GenMatches

data<-read.table("Ovary_Match.txt", header=T, sep="\t")

index<-!is.na(data$length)
data<-data[index, ] 

n<-length(Ovary_bs) #Number of bootstraps 

DE_Seasonal<-rep(NA, n) 
EE_Seasonal<-rep(NA, n) 
OddsRatio<-rep(NA, n) 
p<-rep(NA, n) 
LowCI<-rep(NA, n) 
HighCI<-rep(NA, n) 



for (i in 1:n) {
	
	DE<-data[Ovary_bs[[i]][,1],]
	EE<-data[Ovary_bs[[i]][,2],] 
	
	Sea_matrix<-matrix(c(sum(DE$Seasonal), sum(EE$Seasonal), I(length(DE$Gene)-sum(DE$Seasonal)), I(length(EE$Gene)-sum(EE$Seasonal))), nrow=2, dimnames=list("DE/EE"=c("DE", "EE"), "Seasonal"=c("Yes", "No"))) 
	
	fisher<-fisher.test(Sea_matrix) 
	
	DE_Seasonal[i]<-sum(DE$Seasonal) 
	EE_Seasonal[i]<-sum(EE$Seasonal) 
	OddsRatio[i]<-fisher$estimate 
	p[i]<-fisher$p.value 
	LowCI[i]<-fisher$conf.int[1] 
	HighCI[i]<-fisher$conf.int[2] 
	
} 

result<-cbind(DE_Seasonal, EE_Seasonal, OddsRatio, p, LowCI, HighCI) 
write.table(result, "Ovary_DE_Seasonal_output.txt", quote=F, sep="\t", row.names=F) 


##################################################################################### 

##Load the bootstrap result by double-clicking 

data<-read.table("Head_Match.txt", header=T, sep="\t")

index<-!is.na(data$length)
data<-data[index, ] 

#Clinal<-scan("Clinal", what="") 

n<-length(Head_bs) #Number of bootstraps 


OddsRatio<-rep(NA, n) 
p<-rep(NA, n) 
LowCI<-rep(NA, n) 
HighCI<-rep(NA, n) 
DE_Clinal<-rep(NA, n) 
EE_Clinal<-rep(NA, n) 



for (i in 1:n) {
	
	DE<-data[Head_bs[[i]][,1],]
	EE<-data[Head_bs[[i]][,2],] 
	
	Cli_matrix<-matrix(c(sum(DE$Clinal), sum(EE$Clinal), I(length(DE$Gene)-sum(DE$Clinal)), I(length(EE$Gene)-sum(EE$Clinal))), nrow=2, dimnames=list("DE/EE"=c("DE", "EE"), "Clinal"=c("Yes", "No"))) 
	
	fisher<-fisher.test(Cli_matrix) 
	
	DE_Clinal[i]<-sum(DE$Clinal)
	EE_Clinal[i]<-sum(EE$Clinal)
	OddsRatio[i]<-fisher$estimate 
	p[i]<-fisher$p.value 
	LowCI[i]<-fisher$conf.int[1] 
	HighCI[i]<-fisher$conf.int[2] 
	
} 

result<-cbind(DE_Clinal, EE_Clinal, OddsRatio, p, LowCI, HighCI) 
write.table(result, "Head_DE_Clinal_output.txt", quote=F, sep="\t", row.names=F) 

### 

##Load the bootstrap result by double-clicking 

data<-read.table("Ovary_Match.txt", header=T, sep="\t")

index<-!is.na(data$length)
data<-data[index, ] 

#Clinal<-scan("Clinal", what="") 

n<-length(Ovary_bs) #Number of bootstraps 


OddsRatio<-rep(NA, n) 
p<-rep(NA, n) 
LowCI<-rep(NA, n) 
HighCI<-rep(NA, n) 
DE_Clinal<-rep(NA, n) 
EE_Clinal<-rep(NA, n) 



for (i in 1:n) {
	
	DE<-data[Ovary_bs[[i]][,1],]
	EE<-data[Ovary_bs[[i]][,2],] 
	
	Cli_matrix<-matrix(c(sum(DE$Clinal), sum(EE$Clinal), I(length(DE$Gene)-sum(DE$Clinal)), I(length(EE$Gene)-sum(EE$Clinal))), nrow=2, dimnames=list("DE/EE"=c("DE", "EE"), "Clinal"=c("Yes", "No"))) 
	
	fisher<-fisher.test(Cli_matrix) 
	
	DE_Clinal[i]<-sum(DE$Clinal) 
	EE_Clinal[i]<-sum(EE$Clinal) 
	OddsRatio[i]<-fisher$estimate 
	p[i]<-fisher$p.value 
	LowCI[i]<-fisher$conf.int[1] 
	HighCI[i]<-fisher$conf.int[2] 
	
} 

result<-cbind(DE_Clinal, EE_Clinal, OddsRatio, p, LowCI, HighCI) 
write.table(result, "Ovary_DE_Clinal_output.txt", quote=F, sep="\t", row.names=F) 





